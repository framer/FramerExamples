window.__imported__ = window.__imported__ || {};
window.__imported__["scroll-n-click/layers.json.js"] = [
  {
    "maskFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "id" : "467D259F-657A-4BEC-B60C-B8649B3A5542",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "EA2E254D-4F05-45F5-B120-33C145CE7923",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "A86820BD-4D5F-44EF-AEBB-21FEEF30391A",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-statusBar-A86820BD-4D5F-44EF-AEBB-21FEEF30391A.png",
              "frame" : {
                "y" : 11,
                "x" : 13,
                "width" : 726,
                "height" : 20
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 11,
              "x" : 13,
              "width" : 726,
              "height" : 20
            },
            "name" : "statusBar"
          }
        ],
        "image" : {
          "path" : "images\/Layer-navBar-EA2E254D-4F05-45F5-B120-33C145CE7923.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 128
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 128
        },
        "name" : "navBar"
      },
      {
        "maskFrame" : null,
        "id" : "C7F707CA-04FE-4EE4-995E-06B68173F067",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "5E358598-E973-4248-B288-BE3F2F2C02C1",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-iconAlbums-5E358598-E973-4248-B288-BE3F2F2C02C1.png",
              "frame" : {
                "y" : 1248,
                "x" : 559,
                "width" : 59,
                "height" : 83
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 1248,
              "x" : 559,
              "width" : 59,
              "height" : 83
            },
            "name" : "iconAlbums"
          },
          {
            "maskFrame" : null,
            "id" : "63CB48BD-ED6A-4CF2-809E-50E593D17396",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-iconShared-63CB48BD-ED6A-4CF2-809E-50E593D17396.png",
              "frame" : {
                "y" : 1251,
                "x" : 341,
                "width" : 70,
                "height" : 76
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 1251,
              "x" : 341,
              "width" : 70,
              "height" : 76
            },
            "name" : "iconShared"
          },
          {
            "maskFrame" : null,
            "id" : "F79F21BE-BF0C-42B6-99E2-9DAB0FA42D53",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-iconPhotos-F79F21BE-BF0C-42B6-99E2-9DAB0FA42D53.png",
              "frame" : {
                "y" : 1250,
                "x" : 136,
                "width" : 57,
                "height" : 77
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 1250,
              "x" : 136,
              "width" : 57,
              "height" : 77
            },
            "name" : "iconPhotos"
          }
        ],
        "image" : {
          "path" : "images\/Layer-tabBar-C7F707CA-04FE-4EE4-995E-06B68173F067.png",
          "frame" : {
            "y" : 1236,
            "x" : 0,
            "width" : 750,
            "height" : 100
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 1236,
          "x" : 0,
          "width" : 750,
          "height" : 100
        },
        "name" : "tabBar"
      },
      {
        "maskFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "id" : "36424452-3B6A-4A23-AA43-1ABC9FB87A84",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-content-36424452-3B6A-4A23-AA43-1ABC9FB87A84.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 1334
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "name" : "content"
      }
    ],
    "image" : {
      "path" : "images\/Layer-screen-467D259F-657A-4BEC-B60C-B8649B3A5542.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "screen"
  },
  {
    "maskFrame" : null,
    "id" : "DC63DB5D-EF35-4A60-ADDD-901CA01F335A",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-favActive-DC63DB5D-EF35-4A60-ADDD-901CA01F335A.png",
      "frame" : {
        "y" : 10,
        "x" : 941,
        "width" : 77,
        "height" : 74
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 10,
      "x" : 941,
      "width" : 77,
      "height" : 74
    },
    "name" : "favActive"
  },
  {
    "maskFrame" : null,
    "id" : "0CE2BC51-61F0-4B88-952D-42F8E8CD3227",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-fav-0CE2BC51-61F0-4B88-952D-42F8E8CD3227.png",
      "frame" : {
        "y" : 11,
        "x" : 822,
        "width" : 77,
        "height" : 74
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 11,
      "x" : 822,
      "width" : 77,
      "height" : 74
    },
    "name" : "fav"
  }
]