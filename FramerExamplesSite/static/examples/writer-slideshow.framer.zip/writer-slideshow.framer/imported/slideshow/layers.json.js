window.__imported__ = window.__imported__ || {};
window.__imported__["slideshow/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "B9E2642C-28D7-44D0-984F-446AAE884DEA",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "2FA2E7DA-965F-4643-B6A3-E4ED194F79C3",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/statusbar-2FA2E7DA-965F-4643-B6A3-E4ED194F79C3.png",
          "frame" : {
            "y" : 9,
            "x" : 11,
            "width" : 620,
            "height" : 19
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 9,
          "x" : 11,
          "width" : 620,
          "height" : 19
        },
        "name" : "statusbar"
      },
      {
        "maskFrame" : null,
        "id" : "0BB0CAC7-F12F-438D-B561-01CCCF2E150B",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/slider-0BB0CAC7-F12F-438D-B561-01CCCF2E150B.png",
          "frame" : {
            "y" : 35,
            "x" : 0,
            "width" : 640,
            "height" : 328
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 35,
          "x" : 0,
          "width" : 640,
          "height" : 328
        },
        "name" : "slider"
      }
    ],
    "image" : {
      "path" : "images\/home-B9E2642C-28D7-44D0-984F-446AAE884DEA.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 640,
        "height" : 1136
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 640,
      "height" : 1136
    },
    "name" : "home"
  }
]