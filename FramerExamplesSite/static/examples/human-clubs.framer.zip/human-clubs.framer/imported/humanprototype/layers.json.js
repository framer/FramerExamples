window.__imported__ = window.__imported__ || {};
window.__imported__["show-badges-prototype-9/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "FC183A95-F822-4BFC-A904-DDDF4D965CF9",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-coverphoto-FC183A95-F822-4BFC-A904-DDDF4D965CF9.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 659
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 659
    },
    "name" : "coverphoto"
  },
  {
    "maskFrame" : null,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "BECF137D-4155-4461-84F4-01CEADA7B889",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "53A24D51-0783-43AC-9B02-CB2140C4C0C1",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-newmember-53A24D51-0783-43AC-9B02-CB2140C4C0C1.png",
                  "frame" : {
                    "y" : 619,
                    "x" : 632,
                    "width" : 80,
                    "height" : 80
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 619,
                  "x" : 632,
                  "width" : 80,
                  "height" : 80
                },
                "name" : "newmember"
              },
              {
                "maskFrame" : null,
                "children" : [
                  {
                    "maskFrame" : null,
                    "children" : [
                      {
                        "maskFrame" : null,
                        "id" : "3B9E2E0A-E714-4C70-8B26-457F9E003A9E",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-checkmark_copy_13-3B9E2E0A-E714-4C70-8B26-457F9E003A9E.png",
                          "frame" : {
                            "y" : 675,
                            "x" : 288,
                            "width" : 24,
                            "height" : 24
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 675,
                          "x" : 288,
                          "width" : 24,
                          "height" : 24
                        },
                        "name" : "checkmark_copy_13"
                      },
                      {
                        "maskFrame" : {
                          "y" : 619,
                          "x" : 232,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "01C60138-784E-4480-AE27-462E709FC5B0",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap-01C60138-784E-4480-AE27-462E709FC5B0.png",
                          "frame" : {
                            "y" : 619,
                            "x" : 232,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 619,
                          "x" : 232,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap"
                      }
                    ],
                    "id" : "51B6F28C-8567-4687-8C21-EF74743AE5EE",
                    "visible" : true,
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 619,
                      "x" : 232,
                      "width" : 80,
                      "height" : 80
                    },
                    "name" : "user3"
                  },
                  {
                    "maskFrame" : null,
                    "children" : [
                      {
                        "maskFrame" : {
                          "y" : 619,
                          "x" : 532,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "C60DEAE2-52A6-4071-ABFC-5F0868973F15",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap-C60DEAE2-52A6-4071-ABFC-5F0868973F15.png",
                          "frame" : {
                            "y" : 619,
                            "x" : 532,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 619,
                          "x" : 532,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap"
                      }
                    ],
                    "id" : "6A387C80-368C-4A46-868B-81A200BE20B9",
                    "visible" : true,
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 619,
                      "x" : 532,
                      "width" : 80,
                      "height" : 80
                    },
                    "name" : "user6"
                  },
                  {
                    "maskFrame" : null,
                    "children" : [
                      {
                        "maskFrame" : {
                          "y" : 619,
                          "x" : 432,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "0F28ADED-A297-4A7B-9EAA-0B7FE48ADDDA",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap-0F28ADED-A297-4A7B-9EAA-0B7FE48ADDDA.png",
                          "frame" : {
                            "y" : 619,
                            "x" : 432,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 619,
                          "x" : 432,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap"
                      }
                    ],
                    "id" : "778FE0B5-78AF-4F9C-8051-03A3C5EB4E01",
                    "visible" : true,
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 619,
                      "x" : 432,
                      "width" : 80,
                      "height" : 80
                    },
                    "name" : "user5"
                  },
                  {
                    "maskFrame" : null,
                    "children" : [
                      {
                        "maskFrame" : null,
                        "id" : "2609FCEE-5A6E-47AF-B3DC-4C84B4287CC3",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-checkmark_copy_12-2609FCEE-5A6E-47AF-B3DC-4C84B4287CC3.png",
                          "frame" : {
                            "y" : 675,
                            "x" : 388,
                            "width" : 24,
                            "height" : 24
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 675,
                          "x" : 388,
                          "width" : 24,
                          "height" : 24
                        },
                        "name" : "checkmark_copy_12"
                      },
                      {
                        "maskFrame" : {
                          "y" : 619,
                          "x" : 332,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "5A438ADE-6307-461D-9791-EA0F5E68D845",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap-5A438ADE-6307-461D-9791-EA0F5E68D845.png",
                          "frame" : {
                            "y" : 619,
                            "x" : 332,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 619,
                          "x" : 332,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap"
                      }
                    ],
                    "id" : "A0BE5523-2D1E-48F6-B87F-0F08D62DB4F9",
                    "visible" : true,
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 619,
                      "x" : 332,
                      "width" : 80,
                      "height" : 80
                    },
                    "name" : "user4"
                  },
                  {
                    "maskFrame" : null,
                    "children" : [
                      {
                        "maskFrame" : {
                          "y" : 619,
                          "x" : 731,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "E3D5D602-BB72-4162-9EBB-664DDC3EEFD8",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap-E3D5D602-BB72-4162-9EBB-664DDC3EEFD8.png",
                          "frame" : {
                            "y" : 619,
                            "x" : 731,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 619,
                          "x" : 731,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap"
                      },
                      {
                        "maskFrame" : {
                          "y" : 619,
                          "x" : 632,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "67D3B5AE-B18E-4619-8A1F-55A288FA9FD6",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap-67D3B5AE-B18E-4619-8A1F-55A288FA9FD6.png",
                          "frame" : {
                            "y" : 619,
                            "x" : 632,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 619,
                          "x" : 632,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap"
                      }
                    ],
                    "id" : "0B4697C2-4BB4-4045-A5B1-C1AFEC2B6A7F",
                    "visible" : true,
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 619,
                      "x" : 632,
                      "width" : 179,
                      "height" : 80
                    },
                    "name" : "expandedmembers"
                  }
                ],
                "id" : "FF2C8B08-6135-4C75-89F3-F68C58156B8E",
                "visible" : true,
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 619,
                  "x" : 232,
                  "width" : 579,
                  "height" : 80
                },
                "name" : "othermembers"
              },
              {
                "maskFrame" : null,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "D1E30D51-A742-438A-96A2-24C23FCF43C4",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/Layer-checkmark_copy_10-D1E30D51-A742-438A-96A2-24C23FCF43C4.png",
                      "frame" : {
                        "y" : 675,
                        "x" : 188,
                        "width" : 24,
                        "height" : 24
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 675,
                      "x" : 188,
                      "width" : 24,
                      "height" : 24
                    },
                    "name" : "checkmark_copy_10"
                  },
                  {
                    "maskFrame" : {
                      "y" : 619,
                      "x" : 132,
                      "width" : 80,
                      "height" : 80
                    },
                    "id" : "64E3DA5F-9814-47EA-9575-E165FC4954FA",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/Layer-Bitmap-64E3DA5F-9814-47EA-9575-E165FC4954FA.png",
                      "frame" : {
                        "y" : 619,
                        "x" : 132,
                        "width" : 80,
                        "height" : 80
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 619,
                      "x" : 132,
                      "width" : 80,
                      "height" : 80
                    },
                    "name" : "Bitmap"
                  }
                ],
                "id" : "33030FF1-1AB1-4E93-8D9F-6136755596AD",
                "visible" : true,
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 619,
                  "x" : 132,
                  "width" : 80,
                  "height" : 80
                },
                "name" : "user2"
              },
              {
                "maskFrame" : null,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "E573BC1B-B71D-40BB-94FC-EE084FF625E9",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/Layer-checkmark_copy_11-E573BC1B-B71D-40BB-94FC-EE084FF625E9.png",
                      "frame" : {
                        "y" : 675,
                        "x" : 88,
                        "width" : 24,
                        "height" : 24
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 675,
                      "x" : 88,
                      "width" : 24,
                      "height" : 24
                    },
                    "name" : "checkmark_copy_11"
                  },
                  {
                    "maskFrame" : {
                      "y" : 619,
                      "x" : 32,
                      "width" : 80,
                      "height" : 80
                    },
                    "id" : "4A670FDB-B491-4864-AFA0-E8D89D9D909D",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/Layer-Bitmap_Copy-4A670FDB-B491-4864-AFA0-E8D89D9D909D.png",
                      "frame" : {
                        "y" : 619,
                        "x" : 32,
                        "width" : 80,
                        "height" : 80
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 619,
                      "x" : 32,
                      "width" : 80,
                      "height" : 80
                    },
                    "name" : "Bitmap_Copy"
                  }
                ],
                "id" : "FA69837A-5CFF-41E4-8D5B-E6C5F9104497",
                "visible" : true,
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 619,
                  "x" : 32,
                  "width" : 80,
                  "height" : 80
                },
                "name" : "user1"
              }
            ],
            "id" : "E7755187-E1F0-4B99-9B0B-66D6712A6BCF",
            "visible" : true,
            "imageType" : "png",
            "layerFrame" : {
              "y" : 619,
              "x" : 32,
              "width" : 779,
              "height" : 80
            },
            "name" : "memberslist"
          },
          {
            "maskFrame" : null,
            "id" : "CF5508F2-F625-4257-BFF7-3145115DE63F",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "7C4C1881-13C4-4769-958A-378605AAFB62",
                    "visible" : true,
                    "children" : [
                      {
                        "maskFrame" : {
                          "y" : 768,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "D6B1A2AC-3F9D-471B-A864-62658D431E2A",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap_Copy_3-D6B1A2AC-3F9D-471B-A864-62658D431E2A.png",
                          "frame" : {
                            "y" : 768,
                            "x" : 32,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 768,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap_Copy_3"
                      }
                    ],
                    "image" : {
                      "path" : "images\/Layer-Group_Copy-7C4C1881-13C4-4769-958A-378605AAFB62.png",
                      "frame" : {
                        "y" : 768,
                        "x" : 32,
                        "width" : 673,
                        "height" : 218
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 768,
                      "x" : 32,
                      "width" : 673,
                      "height" : 218
                    },
                    "name" : "Group_Copy"
                  }
                ],
                "id" : "CF355D8A-74F6-4026-A6EF-F2281F3B7CFE",
                "visible" : true,
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 768,
                  "x" : 32,
                  "width" : 673,
                  "height" : 218
                },
                "name" : "message_copy"
              },
              {
                "maskFrame" : null,
                "id" : "7E1B1098-E3B7-40F6-9D4B-DF4A4AB3BD6D",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "1B0413A4-508F-4DE0-A12E-E391883A2B65",
                    "visible" : true,
                    "children" : [
                      {
                        "maskFrame" : {
                          "y" : 1629,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "1ACB8F5E-164C-4208-8411-E9FCA3BF2DF0",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap_Copy_7-1ACB8F5E-164C-4208-8411-E9FCA3BF2DF0.png",
                          "frame" : {
                            "y" : 1629,
                            "x" : 32,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 1629,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap_Copy_7"
                      },
                      {
                        "maskFrame" : {
                          "y" : 1738,
                          "x" : 136,
                          "width" : 578,
                          "height" : 300
                        },
                        "id" : "1CB700E1-98F5-46EB-8E2F-48034E150919",
                        "visible" : true,
                        "children" : [
                          {
                            "maskFrame" : null,
                            "children" : [
                              {
                                "maskFrame" : null,
                                "id" : "073A7C2D-D8A4-4FFD-8BF8-E7401893A6EE",
                                "visible" : true,
                                "children" : [

                                ],
                                "image" : {
                                  "path" : "images\/Layer-Group_Copy_4__213_cal__Oval_65_Copy-073A7C2D-D8A4-4FFD-8BF8-E7401893A6EE.png",
                                  "frame" : {
                                    "y" : 1989,
                                    "x" : 170,
                                    "width" : 520,
                                    "height" : 34
                                  }
                                },
                                "imageType" : "png",
                                "layerFrame" : {
                                  "y" : 1989,
                                  "x" : 170,
                                  "width" : 520,
                                  "height" : 34
                                },
                                "name" : "Group_Copy_4__213_cal__Oval_65_Copy"
                              }
                            ],
                            "id" : "6DF1A447-D19B-492F-8162-70768ECE7A7F",
                            "visible" : true,
                            "imageType" : "png",
                            "layerFrame" : {
                              "y" : 1989,
                              "x" : 170,
                              "width" : 520,
                              "height" : 34
                            },
                            "name" : "Rectangle_86__Group_Copy_4__213_cal__Oval_65_Copy"
                          }
                        ],
                        "image" : {
                          "path" : "images\/Layer-map_overlay-1CB700E1-98F5-46EB-8E2F-48034E150919.png",
                          "frame" : {
                            "y" : 1738,
                            "x" : 136,
                            "width" : 578,
                            "height" : 300
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 1738,
                          "x" : 136,
                          "width" : 578,
                          "height" : 300
                        },
                        "name" : "map_overlay"
                      }
                    ],
                    "image" : {
                      "path" : "images\/Layer-Group_Copy-1B0413A4-508F-4DE0-A12E-E391883A2B65.png",
                      "frame" : {
                        "y" : 1629,
                        "x" : 32,
                        "width" : 682,
                        "height" : 463
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 1629,
                      "x" : 32,
                      "width" : 682,
                      "height" : 463
                    },
                    "name" : "Group_Copy"
                  }
                ],
                "image" : {
                  "path" : "images\/Layer-message_copy_6-7E1B1098-E3B7-40F6-9D4B-DF4A4AB3BD6D.png",
                  "frame" : {
                    "y" : 1598,
                    "x" : 32,
                    "width" : 718,
                    "height" : 494
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 1598,
                  "x" : 32,
                  "width" : 718,
                  "height" : 494
                },
                "name" : "message_copy_6"
              },
              {
                "maskFrame" : null,
                "id" : "A8674CCB-FE50-4BB4-B8F9-8A8654F0E70C",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "1E46BD93-2268-443D-89A1-B21EC9A97B7A",
                    "visible" : true,
                    "children" : [
                      {
                        "maskFrame" : {
                          "y" : 2394,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "A0C43CDE-4E77-4242-AE32-F404306F173D",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap_Copy_9-A0C43CDE-4E77-4242-AE32-F404306F173D.png",
                          "frame" : {
                            "y" : 2394,
                            "x" : 32,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 2394,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap_Copy_9"
                      }
                    ],
                    "image" : {
                      "path" : "images\/Layer-Group_Copy-1E46BD93-2268-443D-89A1-B21EC9A97B7A.png",
                      "frame" : {
                        "y" : 2394,
                        "x" : 32,
                        "width" : 567,
                        "height" : 136
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 2394,
                      "x" : 32,
                      "width" : 567,
                      "height" : 136
                    },
                    "name" : "Group_Copy"
                  }
                ],
                "image" : {
                  "path" : "images\/Layer-message_copy_8-A8674CCB-FE50-4BB4-B8F9-8A8654F0E70C.png",
                  "frame" : {
                    "y" : 2363,
                    "x" : 32,
                    "width" : 718,
                    "height" : 167
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 2363,
                  "x" : 32,
                  "width" : 718,
                  "height" : 167
                },
                "name" : "message_copy_8"
              },
              {
                "maskFrame" : null,
                "id" : "3F173EA5-D30C-4A17-B7DE-1266D2C52814",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "4BFA685A-932F-4B45-AA8F-1935C78A4AC8",
                    "visible" : true,
                    "children" : [
                      {
                        "maskFrame" : {
                          "y" : 2159,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "97E8AABD-D24F-42CD-BD79-6352438F0F92",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap_Copy_8-97E8AABD-D24F-42CD-BD79-6352438F0F92.png",
                          "frame" : {
                            "y" : 2159,
                            "x" : 32,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 2159,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap_Copy_8"
                      }
                    ],
                    "image" : {
                      "path" : "images\/Layer-Group_Copy-4BFA685A-932F-4B45-AA8F-1935C78A4AC8.png",
                      "frame" : {
                        "y" : 2159,
                        "x" : 32,
                        "width" : 548,
                        "height" : 177
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 2159,
                      "x" : 32,
                      "width" : 548,
                      "height" : 177
                    },
                    "name" : "Group_Copy"
                  }
                ],
                "image" : {
                  "path" : "images\/Layer-message_copy_7-3F173EA5-D30C-4A17-B7DE-1266D2C52814.png",
                  "frame" : {
                    "y" : 2128,
                    "x" : 32,
                    "width" : 718,
                    "height" : 208
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 2128,
                  "x" : 32,
                  "width" : 718,
                  "height" : 208
                },
                "name" : "message_copy_7"
              },
              {
                "maskFrame" : null,
                "id" : "870D0CFB-78AB-4C85-BF4D-B689B26FBA74",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-message_copy_11-870D0CFB-78AB-4C85-BF4D-B689B26FBA74.png",
                  "frame" : {
                    "y" : 2573,
                    "x" : 134,
                    "width" : 616,
                    "height" : 1
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 2573,
                  "x" : 134,
                  "width" : 616,
                  "height" : 1
                },
                "name" : "message_copy_11"
              },
              {
                "maskFrame" : null,
                "id" : "6ADB3A47-EBA4-4061-AA3F-CBCDAAFAEEF5",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "children" : [
                      {
                        "maskFrame" : null,
                        "id" : "8733350F-7A0C-4122-AB02-A45607B7B7EC",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Group_4_Copy_3-8733350F-7A0C-4122-AB02-A45607B7B7EC.png",
                          "frame" : {
                            "y" : 1345,
                            "x" : 566,
                            "width" : 234,
                            "height" : 234
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 1345,
                          "x" : 566,
                          "width" : 234,
                          "height" : 234
                        },
                        "name" : "Group_4_Copy_3"
                      }
                    ],
                    "id" : "98ADDE2E-B5FE-4A40-A953-02BA182901CD",
                    "visible" : true,
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 1345,
                      "x" : 566,
                      "width" : 234,
                      "height" : 234
                    },
                    "name" : "likebutton_copy_14"
                  },
                  {
                    "maskFrame" : null,
                    "id" : "52354883-A6E4-4E8E-AC10-2D9AC267E929",
                    "visible" : true,
                    "children" : [
                      {
                        "maskFrame" : {
                          "y" : 1435,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "051B2D4C-6FAE-4C7A-9A60-D7E923FD94F1",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap_Copy_6-051B2D4C-6FAE-4C7A-9A60-D7E923FD94F1.png",
                          "frame" : {
                            "y" : 1435,
                            "x" : 32,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 1435,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap_Copy_6"
                      }
                    ],
                    "image" : {
                      "path" : "images\/Layer-Group_Copy-52354883-A6E4-4E8E-AC10-2D9AC267E929.png",
                      "frame" : {
                        "y" : 1435,
                        "x" : 32,
                        "width" : 421,
                        "height" : 136
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 1435,
                      "x" : 32,
                      "width" : 421,
                      "height" : 136
                    },
                    "name" : "Group_Copy"
                  }
                ],
                "image" : {
                  "path" : "images\/Layer-message_copy_5-6ADB3A47-EBA4-4061-AA3F-CBCDAAFAEEF5.png",
                  "frame" : {
                    "y" : 1404,
                    "x" : 32,
                    "width" : 718,
                    "height" : 167
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 1404,
                  "x" : 32,
                  "width" : 718,
                  "height" : 167
                },
                "name" : "message_copy_5"
              },
              {
                "maskFrame" : null,
                "id" : "51CEC1E0-37A4-4C60-8DBE-EAA39E220D43",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "87A2F151-90CC-4980-9F50-4667ECA106FD",
                    "visible" : true,
                    "children" : [
                      {
                        "maskFrame" : null,
                        "children" : [
                          {
                            "maskFrame" : null,
                            "id" : "F6ACCA64-5B69-4F6E-BD8A-1F7562B19220",
                            "visible" : true,
                            "children" : [

                            ],
                            "image" : {
                              "path" : "images\/Layer-Group_4_Copy_3-F6ACCA64-5B69-4F6E-BD8A-1F7562B19220.png",
                              "frame" : {
                                "y" : 1151,
                                "x" : 566,
                                "width" : 234,
                                "height" : 234
                              }
                            },
                            "imageType" : "png",
                            "layerFrame" : {
                              "y" : 1151,
                              "x" : 566,
                              "width" : 234,
                              "height" : 234
                            },
                            "name" : "Group_4_Copy_3"
                          }
                        ],
                        "id" : "C057E519-F03C-4891-9521-7192AC1A008D",
                        "visible" : true,
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 1151,
                          "x" : 566,
                          "width" : 234,
                          "height" : 234
                        },
                        "name" : "likebutton_copy_13"
                      },
                      {
                        "maskFrame" : {
                          "y" : 1241,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "D6B3AC28-2ADD-4F0B-B064-2C624CB6AA1B",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap_Copy_5-D6B3AC28-2ADD-4F0B-B064-2C624CB6AA1B.png",
                          "frame" : {
                            "y" : 1241,
                            "x" : 32,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 1241,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap_Copy_5"
                      }
                    ],
                    "image" : {
                      "path" : "images\/Layer-Group_Copy-87A2F151-90CC-4980-9F50-4667ECA106FD.png",
                      "frame" : {
                        "y" : 1241,
                        "x" : 32,
                        "width" : 593,
                        "height" : 136
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 1241,
                      "x" : 32,
                      "width" : 593,
                      "height" : 136
                    },
                    "name" : "Group_Copy"
                  }
                ],
                "image" : {
                  "path" : "images\/Layer-message_copy_4-51CEC1E0-37A4-4C60-8DBE-EAA39E220D43.png",
                  "frame" : {
                    "y" : 1210,
                    "x" : 32,
                    "width" : 718,
                    "height" : 167
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 1210,
                  "x" : 32,
                  "width" : 718,
                  "height" : 167
                },
                "name" : "message_copy_4"
              },
              {
                "maskFrame" : null,
                "id" : "0439F618-D5C7-4ED4-87EE-2104E03F276B",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "children" : [
                      {
                        "maskFrame" : null,
                        "id" : "EE894F25-6F61-4A71-A777-5A2C468869A3",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Group_4_Copy_3-EE894F25-6F61-4A71-A777-5A2C468869A3.png",
                          "frame" : {
                            "y" : 957,
                            "x" : 566,
                            "width" : 234,
                            "height" : 234
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 957,
                          "x" : 566,
                          "width" : 234,
                          "height" : 234
                        },
                        "name" : "Group_4_Copy_3"
                      }
                    ],
                    "id" : "0279649F-32DF-4EA5-81AC-75302E7E0E55",
                    "visible" : true,
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 957,
                      "x" : 566,
                      "width" : 234,
                      "height" : 234
                    },
                    "name" : "likebutton_copy_9"
                  },
                  {
                    "maskFrame" : null,
                    "id" : "1C7FD2F9-9875-4CB0-97F8-299850AA9262",
                    "visible" : true,
                    "children" : [
                      {
                        "maskFrame" : {
                          "y" : 1047,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "id" : "89D1F5E1-0998-493F-8323-92F723A82C52",
                        "visible" : true,
                        "children" : [

                        ],
                        "image" : {
                          "path" : "images\/Layer-Bitmap_Copy_2-89D1F5E1-0998-493F-8323-92F723A82C52.png",
                          "frame" : {
                            "y" : 1047,
                            "x" : 32,
                            "width" : 80,
                            "height" : 80
                          }
                        },
                        "imageType" : "png",
                        "layerFrame" : {
                          "y" : 1047,
                          "x" : 32,
                          "width" : 80,
                          "height" : 80
                        },
                        "name" : "Bitmap_Copy_2"
                      }
                    ],
                    "image" : {
                      "path" : "images\/Layer-Group_Copy-1C7FD2F9-9875-4CB0-97F8-299850AA9262.png",
                      "frame" : {
                        "y" : 1046,
                        "x" : 32,
                        "width" : 471,
                        "height" : 137
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 1046,
                      "x" : 32,
                      "width" : 471,
                      "height" : 137
                    },
                    "name" : "Group_Copy"
                  }
                ],
                "image" : {
                  "path" : "images\/Layer-message_copy_3-0439F618-D5C7-4ED4-87EE-2104E03F276B.png",
                  "frame" : {
                    "y" : 1016,
                    "x" : 32,
                    "width" : 718,
                    "height" : 167
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 1016,
                  "x" : 32,
                  "width" : 718,
                  "height" : 167
                },
                "name" : "message_copy_3"
              }
            ],
            "image" : {
              "path" : "images\/Layer-Group-CF5508F2-F625-4257-BFF7-3145115DE63F.png",
              "frame" : {
                "y" : 768,
                "x" : 32,
                "width" : 718,
                "height" : 1828
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 768,
              "x" : 32,
              "width" : 718,
              "height" : 1828
            },
            "name" : "Group"
          }
        ],
        "image" : {
          "path" : "images\/Layer-bottomcontent-BECF137D-4155-4461-84F4-01CEADA7B889.png",
          "frame" : {
            "y" : 619,
            "x" : 32,
            "width" : 779,
            "height" : 1977
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 619,
          "x" : 32,
          "width" : 779,
          "height" : 1977
        },
        "name" : "bottomcontent"
      },
      {
        "maskFrame" : null,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "AAA31FEF-BA84-4F8D-A912-F841523E17C0",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-avg-AAA31FEF-BA84-4F8D-A912-F841523E17C0.png",
              "frame" : {
                "y" : 742,
                "x" : 169,
                "width" : 153,
                "height" : 56
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 742,
              "x" : 169,
              "width" : 153,
              "height" : 56
            },
            "name" : "avg"
          },
          {
            "maskFrame" : null,
            "id" : "D1BC2213-4C7D-4FCE-A4C8-0A63AF848991",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-robert-D1BC2213-4C7D-4FCE-A4C8-0A63AF848991.png",
              "frame" : {
                "y" : 620,
                "x" : 30,
                "width" : 688,
                "height" : 98
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 620,
              "x" : 30,
              "width" : 688,
              "height" : 98
            },
            "name" : "robert"
          },
          {
            "maskFrame" : null,
            "id" : "BA10D0E1-5AB9-43C6-A604-8C2397942769",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-stijn-BA10D0E1-5AB9-43C6-A604-8C2397942769.png",
              "frame" : {
                "y" : 619,
                "x" : 30,
                "width" : 688,
                "height" : 99
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 619,
              "x" : 30,
              "width" : 688,
              "height" : 99
            },
            "name" : "stijn"
          },
          {
            "maskFrame" : null,
            "id" : "24F907DE-7AD3-4FA9-8734-D18C2DFF914D",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "548B7A34-617D-48FB-AC24-094D0EED15BD",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Rectangle_274_Copy_2__Rectangle_274_Copy-548B7A34-617D-48FB-AC24-094D0EED15BD.png",
                  "frame" : {
                    "y" : 641,
                    "x" : -68,
                    "width" : 527,
                    "height" : 210
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 641,
                  "x" : -68,
                  "width" : 527,
                  "height" : 210
                },
                "name" : "Rectangle_274_Copy_2__Rectangle_274_Copy"
              },
              {
                "maskFrame" : null,
                "children" : [

                ],
                "id" : "A08B5CB8-5920-403E-99BF-B73B9DF57099",
                "visible" : true,
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 641,
                  "x" : 62,
                  "width" : 397,
                  "height" : 210
                },
                "name" : "progress"
              }
            ],
            "image" : {
              "path" : "images\/Layer-Rectangle_274__Rectangle_274_Copy-24F907DE-7AD3-4FA9-8734-D18C2DFF914D.png",
              "frame" : {
                "y" : 742,
                "x" : 32,
                "width" : 686,
                "height" : 8
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 742,
              "x" : 32,
              "width" : 686,
              "height" : 8
            },
            "name" : "Rectangle_274__Rectangle_274_Copy"
          },
          {
            "maskFrame" : null,
            "id" : "0A1AABE6-061A-4CD9-A585-AF26B27335C4",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-Group_Copy_3-0A1AABE6-061A-4CD9-A585-AF26B27335C4.png",
              "frame" : {
                "y" : 625,
                "x" : 595,
                "width" : 125,
                "height" : 19
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 625,
              "x" : 595,
              "width" : 125,
              "height" : 19
            },
            "name" : "Group_Copy_3"
          }
        ],
        "id" : "73B08EBD-D47E-4A98-ACBB-996F8BA80F49",
        "visible" : true,
        "imageType" : "png",
        "layerFrame" : {
          "y" : 619,
          "x" : 30,
          "width" : 690,
          "height" : 179
        },
        "name" : "personcopy"
      }
    ],
    "id" : "0A306546-A095-48FF-BC4C-B3FFB7EEF55F",
    "visible" : true,
    "imageType" : "png",
    "layerFrame" : {
      "y" : 619,
      "x" : 30,
      "width" : 781,
      "height" : 1977
    },
    "name" : "copy"
  },
  {
    "maskFrame" : null,
    "id" : "101A8EDC-D960-4273-9BF3-3F4AC9522F74",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "8EE2F733-2F94-488E-AD56-64B13065B963",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "A4DBDA1C-F789-46B8-9209-60FC63015196",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-Rectangle_433__Rectangle_433_Copy-A4DBDA1C-F789-46B8-9209-60FC63015196.png",
              "frame" : {
                "y" : 413,
                "x" : 489,
                "width" : 233,
                "height" : 233
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 413,
              "x" : 489,
              "width" : 233,
              "height" : 233
            },
            "name" : "Rectangle_433__Rectangle_433_Copy"
          }
        ],
        "image" : {
          "path" : "images\/Layer-clubtitle-8EE2F733-2F94-488E-AD56-64B13065B963.png",
          "frame" : {
            "y" : 475,
            "x" : 33,
            "width" : 255,
            "height" : 76
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 475,
          "x" : 33,
          "width" : 255,
          "height" : 76
        },
        "name" : "clubtitle"
      }
    ],
    "image" : {
      "path" : "images\/Layer-title-101A8EDC-D960-4273-9BF3-3F4AC9522F74.png",
      "frame" : {
        "y" : 475,
        "x" : 33,
        "width" : 685,
        "height" : 76
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 475,
      "x" : 33,
      "width" : 685,
      "height" : 76
    },
    "name" : "title"
  },
  {
    "maskFrame" : null,
    "id" : "E17C50ED-0CF0-403D-8090-C98FD029BF98",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-divider-E17C50ED-0CF0-403D-8090-C98FD029BF98.png",
      "frame" : {
        "y" : 583,
        "x" : 32,
        "width" : 718,
        "height" : 1
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 583,
      "x" : 32,
      "width" : 718,
      "height" : 1
    },
    "name" : "divider"
  },
  {
    "maskFrame" : null,
    "id" : "72A64BFF-BFB0-4FB6-A25F-6B47F6A05724",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-titlebarbg-72A64BFF-BFB0-4FB6-A25F-6B47F6A05724.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 129
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 129
    },
    "name" : "titlebarbg"
  },
  {
    "maskFrame" : null,
    "id" : "9168E536-EDE9-4A2F-B88B-9A4504459E1A",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-stahtus-9168E536-EDE9-4A2F-B88B-9A4504459E1A.png",
      "frame" : {
        "y" : 11,
        "x" : 13,
        "width" : 726,
        "height" : 23
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 11,
      "x" : 13,
      "width" : 726,
      "height" : 23
    },
    "name" : "stahtus"
  },
  {
    "maskFrame" : null,
    "children" : [
      {
        "maskFrame" : null,
        "children" : [
          {
            "maskFrame" : null,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "69DF625E-E9FF-4D15-BDE1-D3817A2F0B0D",
                "visible" : false,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Rectangle_773__Rectangle_774-69DF625E-E9FF-4D15-BDE1-D3817A2F0B0D.png",
                  "frame" : {
                    "y" : -38,
                    "x" : 582,
                    "width" : 238,
                    "height" : 238
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : -38,
                  "x" : 582,
                  "width" : 238,
                  "height" : 238
                },
                "name" : "Rectangle_773__Rectangle_774"
              }
            ],
            "id" : "D67F3C2E-66E2-4281-8845-2FA1E83A5328",
            "visible" : true,
            "imageType" : "png",
            "layerFrame" : {
              "y" : -38,
              "x" : 582,
              "width" : 238,
              "height" : 238
            },
            "name" : "Group_Copy_3__Rectangle_528_Copy_3__Group_Copy_Copy_Copy"
          }
        ],
        "id" : "9A38CE06-7BD0-4158-BFC4-920769A603FD",
        "visible" : true,
        "imageType" : "png",
        "layerFrame" : {
          "y" : -38,
          "x" : 582,
          "width" : 238,
          "height" : 238
        },
        "name" : "jeaj_copy"
      }
    ],
    "id" : "1E567C40-E915-48A4-8E2E-062576D2F1D1",
    "visible" : true,
    "imageType" : "png",
    "layerFrame" : {
      "y" : -38,
      "x" : 582,
      "width" : 238,
      "height" : 238
    },
    "name" : "posticon"
  },
  {
    "maskFrame" : null,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "7BD4A724-D15A-4B13-BBA2-C1512F5997A3",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-clubtitle-7BD4A724-D15A-4B13-BBA2-C1512F5997A3.png",
          "frame" : {
            "y" : 71,
            "x" : 274,
            "width" : 204,
            "height" : 32
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 71,
          "x" : 274,
          "width" : 204,
          "height" : 32
        },
        "name" : "clubtitle"
      },
      {
        "maskFrame" : null,
        "id" : "0F97AA3B-D4CF-4433-AB4E-4C71956E070A",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-newpost-0F97AA3B-D4CF-4433-AB4E-4C71956E070A.png",
          "frame" : {
            "y" : 65,
            "x" : 684,
            "width" : 42,
            "height" : 39
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 65,
          "x" : 684,
          "width" : 42,
          "height" : 39
        },
        "name" : "newpost"
      },
      {
        "maskFrame" : null,
        "id" : "C33097FB-3442-4A7E-AB9E-341DFA6863E3",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-writepost-C33097FB-3442-4A7E-AB9E-341DFA6863E3.png",
          "frame" : {
            "y" : 71,
            "x" : 22,
            "width" : 706,
            "height" : 26
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 71,
          "x" : 22,
          "width" : 706,
          "height" : 26
        },
        "name" : "writepost"
      }
    ],
    "id" : "82C86579-88B4-4FB9-90EF-5E0C1546B4E0",
    "visible" : true,
    "imageType" : "png",
    "layerFrame" : {
      "y" : 65,
      "x" : 22,
      "width" : 706,
      "height" : 39
    },
    "name" : "pagetitle"
  },
  {
    "maskFrame" : null,
    "id" : "D95D8398-A94F-4D4A-8F1B-331048933F2D",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-controlsback_2-D95D8398-A94F-4D4A-8F1B-331048933F2D.png",
      "frame" : {
        "y" : 63,
        "x" : 17,
        "width" : 124,
        "height" : 43
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 63,
      "x" : 17,
      "width" : 124,
      "height" : 43
    },
    "name" : "controlsback_2"
  }
]