window.__imported__ = window.__imported__ || {};
window.__imported__["player/layers.json.js"] = [
  {
    "maskFrame" : null,
    "visible" : true,
    "id" : "CABFCF3F-5571-4A31-B7F1-CD09B8DA8675",
    "children" : [
      {
        "maskFrame" : null,
        "visible" : true,
        "id" : "0C49ED71-784C-4319-99DE-E4487A8EC39E",
        "children" : [
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "C3EB74E3-D7E9-46D3-8730-4B9858B363B9",
            "children" : [

            ],
            "image" : {
              "path" : "images\/navbar-C3EB74E3-D7E9-46D3-8730-4B9858B363B9.png",
              "frame" : {
                "y" : 592,
                "x" : 0,
                "width" : 360,
                "height" : 48
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 592,
              "x" : 0,
              "width" : 360,
              "height" : 48
            },
            "name" : "navbar"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "BA56AC90-C12F-4841-8E33-9C9BA406C077",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "708D3D06-CF8F-4398-9B60-7ECC47122D35",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Iconbattery-708D3D06-CF8F-4398-9B60-7ECC47122D35.png",
                  "frame" : {
                    "y" : 5,
                    "x" : 301,
                    "width" : 8,
                    "height" : 13
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 5,
                  "x" : 301,
                  "width" : 8,
                  "height" : 13
                },
                "name" : "Iconbattery"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "D4A95F57-2F9C-4E85-8422-8D325171BC09",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Iconnetwork-D4A95F57-2F9C-4E85-8422-8D325171BC09.png",
                  "frame" : {
                    "y" : 6,
                    "x" : 275,
                    "width" : 12,
                    "height" : 12
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 6,
                  "x" : 275,
                  "width" : 12,
                  "height" : 12
                },
                "name" : "Iconnetwork"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "97EFFBA2-7684-42B6-B56F-FF1E22779B1E",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Iconwifi-97EFFBA2-7684-42B6-B56F-FF1E22779B1E.png",
                  "frame" : {
                    "y" : 6,
                    "x" : 250,
                    "width" : 13,
                    "height" : 12
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 6,
                  "x" : 250,
                  "width" : 13,
                  "height" : 12
                },
                "name" : "Iconwifi"
              }
            ],
            "image" : {
              "path" : "images\/statusbar-BA56AC90-C12F-4841-8E33-9C9BA406C077.png",
              "frame" : {
                "y" : 0,
                "x" : 0,
                "width" : 360,
                "height" : 24
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 0,
              "x" : 0,
              "width" : 360,
              "height" : 24
            },
            "name" : "statusbar"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "DF530ACA-CC06-42FD-85F4-90D0E6277B97",
            "children" : [

            ],
            "image" : {
              "path" : "images\/timer-DF530ACA-CC06-42FD-85F4-90D0E6277B97.png",
              "frame" : {
                "y" : 360,
                "x" : 0,
                "width" : 4,
                "height" : 20
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 360,
              "x" : 0,
              "width" : 4,
              "height" : 20
            },
            "name" : "timer"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "66B2B560-4D69-413A-97DA-D2662A6E2568",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "37BD82A8-2CD8-4F91-ACF9-2F94649D6886",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/btn_pause-37BD82A8-2CD8-4F91-ACF9-2F94649D6886.png",
                  "frame" : {
                    "y" : 457,
                    "x" : 174,
                    "width" : 12,
                    "height" : 18
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 457,
                  "x" : 174,
                  "width" : 12,
                  "height" : 18
                },
                "name" : "btn_pause"
              }
            ],
            "image" : {
              "path" : "images\/controller-66B2B560-4D69-413A-97DA-D2662A6E2568.png",
              "frame" : {
                "y" : 360,
                "x" : 0,
                "width" : 360,
                "height" : 139
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 360,
              "x" : 0,
              "width" : 360,
              "height" : 139
            },
            "name" : "controller"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "9EF68BC6-CBE7-4EC1-8F4E-93696DB325FE",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "9F1C76CE-7ED1-462C-9DA4-7F38408C4DF4",
                "children" : [
                  {
                    "maskFrame" : null,
                    "visible" : true,
                    "id" : "34477FEB-B4F3-4147-9A67-273A0A72320C",
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/btn_play-34477FEB-B4F3-4147-9A67-273A0A72320C.png",
                      "frame" : {
                        "y" : 231,
                        "x" : 307,
                        "width" : 17,
                        "height" : 17
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 231,
                      "x" : 307,
                      "width" : 17,
                      "height" : 17
                    },
                    "name" : "btn_play"
                  },
                  {
                    "maskFrame" : null,
                    "visible" : true,
                    "id" : "DF822956-D372-4D86-A9CE-A6396F286749",
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/button-DF822956-D372-4D86-A9CE-A6396F286749.png",
                      "frame" : {
                        "y" : 211,
                        "x" : 284,
                        "width" : 62,
                        "height" : 62
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 211,
                      "x" : 284,
                      "width" : 62,
                      "height" : 62
                    },
                    "name" : "button"
                  }
                ],
                "image" : {
                  "path" : "images\/playercontrol-9F1C76CE-7ED1-462C-9DA4-7F38408C4DF4.png",
                  "frame" : {
                    "y" : 190,
                    "x" : 137,
                    "width" : 226,
                    "height" : 106
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 190,
                  "x" : 137,
                  "width" : 226,
                  "height" : 106
                },
                "name" : "playercontrol"
              }
            ],
            "image" : {
              "path" : "images\/playercontainer-9EF68BC6-CBE7-4EC1-8F4E-93696DB325FE.png",
              "frame" : {
                "y" : 175,
                "x" : -3,
                "width" : 366,
                "height" : 145
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 175,
              "x" : -3,
              "width" : 366,
              "height" : 145
            },
            "name" : "playercontainer"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "056147DC-C36F-4C5C-95A9-82CAEA7EFD82",
            "children" : [

            ],
            "image" : {
              "path" : "images\/metadata-056147DC-C36F-4C5C-95A9-82CAEA7EFD82.png",
              "frame" : {
                "y" : 261,
                "x" : 18,
                "width" : 188,
                "height" : 45
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 261,
              "x" : 18,
              "width" : 188,
              "height" : 45
            },
            "name" : "metadata"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "8DE6041F-1D51-4C7E-AE8C-31277BC41A15",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "61DEDCFD-A4DD-4E00-80C5-5E4FDCA7C005",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/list_item_4-61DEDCFD-A4DD-4E00-80C5-5E4FDCA7C005.png",
                  "frame" : {
                    "y" : 579,
                    "x" : 0,
                    "width" : 360,
                    "height" : 80
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 579,
                  "x" : 0,
                  "width" : 360,
                  "height" : 80
                },
                "name" : "list_item_4"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "6AC7B7A4-B84D-4FCA-8ACD-29784C0B3CEB",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/list_item_3-6AC7B7A4-B84D-4FCA-8ACD-29784C0B3CEB.png",
                  "frame" : {
                    "y" : 499,
                    "x" : 0,
                    "width" : 360,
                    "height" : 80
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 499,
                  "x" : 0,
                  "width" : 360,
                  "height" : 80
                },
                "name" : "list_item_3"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "F0E768FC-AEE6-4D17-8992-7FD8F71F0CF1",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/list_item_2-F0E768FC-AEE6-4D17-8992-7FD8F71F0CF1.png",
                  "frame" : {
                    "y" : 419,
                    "x" : 0,
                    "width" : 360,
                    "height" : 80
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 419,
                  "x" : 0,
                  "width" : 360,
                  "height" : 80
                },
                "name" : "list_item_2"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "48BA6916-17A2-450A-A229-618C2E835AAF",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/list_item-48BA6916-17A2-450A-A229-618C2E835AAF.png",
                  "frame" : {
                    "y" : 339,
                    "x" : 0,
                    "width" : 360,
                    "height" : 80
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 339,
                  "x" : 0,
                  "width" : 360,
                  "height" : 80
                },
                "name" : "list_item"
              }
            ],
            "image" : {
              "path" : "images\/content-8DE6041F-1D51-4C7E-AE8C-31277BC41A15.png",
              "frame" : {
                "y" : 241,
                "x" : -4,
                "width" : 368,
                "height" : 424
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 241,
              "x" : -4,
              "width" : 368,
              "height" : 424
            },
            "name" : "content"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "24589CAC-5C84-4E02-A29D-954B9314FDD6",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "14AE05C1-6846-4445-8D80-5FD8ABBFD789",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Controls-14AE05C1-6846-4445-8D80-5FD8ABBFD789.png",
                  "frame" : {
                    "y" : 43,
                    "x" : 19,
                    "width" : 308,
                    "height" : 17
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 43,
                  "x" : 19,
                  "width" : 308,
                  "height" : 17
                },
                "name" : "Controls"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "E88C8382-E957-420A-ADEC-D5EE2038F96E",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/441367-E88C8382-E957-420A-ADEC-D5EE2038F96E.png",
                  "frame" : {
                    "y" : 0,
                    "x" : 0,
                    "width" : 360,
                    "height" : 360
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 0,
                  "x" : 0,
                  "width" : 360,
                  "height" : 360
                },
                "name" : "layerX"
              }
            ],
            "image" : {
              "path" : "images\/appbar-24589CAC-5C84-4E02-A29D-954B9314FDD6.png",
              "frame" : {
                "y" : -1,
                "x" : -3,
                "width" : 366,
                "height" : 366
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : -1,
              "x" : -3,
              "width" : 366,
              "height" : 366
            },
            "name" : "appbar"
          }
        ],
        "image" : {
          "path" : "images\/View-0C49ED71-784C-4319-99DE-E4487A8EC39E.png",
          "frame" : {
            "y" : -2,
            "x" : -4,
            "width" : 368,
            "height" : 667
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : -2,
          "x" : -4,
          "width" : 368,
          "height" : 667
        },
        "name" : "View"
      }
    ],
    "image" : {
      "path" : "images\/album_page-CABFCF3F-5571-4A31-B7F1-CD09B8DA8675.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 360,
        "height" : 640
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 360,
      "height" : 640
    },
    "name" : "album_page"
  }
]
