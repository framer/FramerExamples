window.__imported__ = window.__imported__ || {};
window.__imported__["blurredbg/layers.json.js"] = [
  {
    "maskFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 640,
      "height" : 1136
    },
    "id" : "B07CE853-2C4A-436E-A10F-760160A1BFF5",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "7F47C4AA-6239-4AC6-A326-A2ED105E1455",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/feed-7F47C4AA-6239-4AC6-A326-A2ED105E1455.png",
          "frame" : {
            "y" : 130,
            "x" : 0,
            "width" : 640,
            "height" : 2577
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 130,
          "x" : 0,
          "width" : 640,
          "height" : 2577
        },
        "name" : "feed"
      }
    ],
    "image" : {
      "path" : "images\/scroll-B07CE853-2C4A-436E-A10F-760160A1BFF5.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 640,
        "height" : 1136
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 640,
      "height" : 1136
    },
    "name" : "scroll"
  },
  {
    "maskFrame" : null,
    "id" : "761BE128-A773-4A80-94EA-A29AA34D58BA",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/tabbar-761BE128-A773-4A80-94EA-A29AA34D58BA.png",
      "frame" : {
        "y" : 1048,
        "x" : 0,
        "width" : 640,
        "height" : 89
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 1048,
      "x" : 0,
      "width" : 640,
      "height" : 89
    },
    "name" : "tabbar"
  },
  {
    "maskFrame" : null,
    "id" : "8AAD16F5-3467-4D7D-A87F-E6B696BCC518",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "4FDE49E6-9DF7-4173-ADEA-21284CED997D",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/text-4FDE49E6-9DF7-4173-ADEA-21284CED997D.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 640,
            "height" : 130
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 640,
          "height" : 130
        },
        "name" : "text"
      }
    ],
    "image" : {
      "path" : "images\/navbar-8AAD16F5-3467-4D7D-A87F-E6B696BCC518.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 640,
        "height" : 130
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 640,
      "height" : 130
    },
    "name" : "navbar"
  }
]