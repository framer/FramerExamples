window.__imported__ = window.__imported__ || {};
window.__imported__["tryout2/layers.json.js"] = [
	{
		"id": 829,
		"name": "Wallpaper",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Wallpaper.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 640,
				"height": 1136
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1252969069"
	},
	{
		"id": 2259,
		"name": "Springboard",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Springboard.png",
			"frame": {
				"x": 0,
				"y": 68,
				"width": 640,
				"height": 1068
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "384189082"
	},
	{
		"id": 2271,
		"name": "Notification",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Notification.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 640,
				"height": 168
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "760916531"
	},
	{
		"id": 2264,
		"name": "Healthbookicon",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Healthbookicon.png",
			"frame": {
				"x": 336,
				"y": 752,
				"width": 122,
				"height": 149
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1656274755"
	},
	{
		"id": 371,
		"name": "Emergencycard",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Emergencycard.png",
			"frame": {
				"x": 0,
				"y": 139,
				"width": 640,
				"height": 845
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "640097150"
	},
	{
		"id": 369,
		"name": "Activity",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Activity.png",
			"frame": {
				"x": 0,
				"y": 282,
				"width": 640,
				"height": 845
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1993164447"
	},
	{
		"id": 367,
		"name": "Cholestrol",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Cholestrol.png",
			"frame": {
				"x": 0,
				"y": 425,
				"width": 640,
				"height": 845
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "2095780650"
	},
	{
		"id": 365,
		"name": "Respiratoryrate",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Respiratoryrate.png",
			"frame": {
				"x": 0,
				"y": 568,
				"width": 640,
				"height": 845
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "724429655"
	},
	{
		"id": 363,
		"name": "Heartrate",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Heartrate.png",
			"frame": {
				"x": 0,
				"y": 711,
				"width": 640,
				"height": 845
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "2015924754"
	},
	{
		"id": 361,
		"name": "Sleep",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Sleep.png",
			"frame": {
				"x": 0,
				"y": 854,
				"width": 640,
				"height": 845
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1672028927"
	},
	{
		"id": 359,
		"name": "Nutrition",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Nutrition.png",
			"frame": {
				"x": 0,
				"y": 997,
				"width": 640,
				"height": 845
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1768404510"
	},
	{
		"id": 1481,
		"name": "Welcome",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Welcome.png",
			"frame": {
				"x": 0,
				"y": 145,
				"width": 640,
				"height": 955
			}
		},
		"imageType": "png",
		"children": [
			{
				"id": 1644,
				"name": "Start",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 640,
					"height": 1842
				},
				"maskFrame": null,
				"image": {
					"path": "images/Start.png",
					"frame": {
						"x": 147,
						"y": 998,
						"width": 347,
						"height": 32
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "410911363"
			}
		],
		"modification": "1737309358"
	},
	{
		"id": 1726,
		"name": "Watch",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1842
		},
		"maskFrame": null,
		"image": {
			"path": "images/Watch.png",
			"frame": {
				"x": 209,
				"y": 62,
				"width": 397,
				"height": 52
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "886383922"
	}
]