window.__imported__ = window.__imported__ || {};
window.__imported__["page-simple/layers.json.js"] = [
  {
    "maskFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "id" : "467D259F-657A-4BEC-B60C-B8649B3A5542",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "EA2E254D-4F05-45F5-B120-33C145CE7923",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "A86820BD-4D5F-44EF-AEBB-21FEEF30391A",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-statusBar-A86820BD-4D5F-44EF-AEBB-21FEEF30391A.png",
              "frame" : {
                "y" : 11,
                "x" : 13,
                "width" : 726,
                "height" : 20
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 11,
              "x" : 13,
              "width" : 726,
              "height" : 20
            },
            "name" : "statusBar"
          }
        ],
        "image" : {
          "path" : "images\/Layer-navBar-EA2E254D-4F05-45F5-B120-33C145CE7923.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 128
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 128
        },
        "name" : "navBar"
      },
      {
        "maskFrame" : null,
        "id" : "32ED0AEA-D4A5-4F4D-847D-EBD640E595BD",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "669740E0-5E23-4CAB-8442-62B0F917279B",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-iconAlbums-669740E0-5E23-4CAB-8442-62B0F917279B.png",
              "frame" : {
                "y" : 1246,
                "x" : 559,
                "width" : 59,
                "height" : 83
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 1246,
              "x" : 559,
              "width" : 59,
              "height" : 83
            },
            "name" : "iconAlbums"
          },
          {
            "maskFrame" : null,
            "id" : "61B60753-DBC3-4A3D-8C3B-5D407EBED321",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-iconShared-61B60753-DBC3-4A3D-8C3B-5D407EBED321.png",
              "frame" : {
                "y" : 1249,
                "x" : 341,
                "width" : 70,
                "height" : 76
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 1249,
              "x" : 341,
              "width" : 70,
              "height" : 76
            },
            "name" : "iconShared"
          },
          {
            "maskFrame" : null,
            "id" : "B3147D7A-D66F-4F77-AAF9-6CFB68D4DABB",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-iconPhotos-B3147D7A-D66F-4F77-AAF9-6CFB68D4DABB.png",
              "frame" : {
                "y" : 1248,
                "x" : 136,
                "width" : 57,
                "height" : 77
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 1248,
              "x" : 136,
              "width" : 57,
              "height" : 77
            },
            "name" : "iconPhotos"
          }
        ],
        "image" : {
          "path" : "images\/Layer-tabBar-32ED0AEA-D4A5-4F4D-847D-EBD640E595BD.png",
          "frame" : {
            "y" : 1234,
            "x" : 0,
            "width" : 750,
            "height" : 100
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 1234,
          "x" : 0,
          "width" : 750,
          "height" : 100
        },
        "name" : "tabBar"
      },
      {
        "maskFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "id" : "36424452-3B6A-4A23-AA43-1ABC9FB87A84",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-content-36424452-3B6A-4A23-AA43-1ABC9FB87A84.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 1334
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "name" : "content"
      }
    ],
    "image" : {
      "path" : "images\/Layer-screen-467D259F-657A-4BEC-B60C-B8649B3A5542.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "screen"
  }
]