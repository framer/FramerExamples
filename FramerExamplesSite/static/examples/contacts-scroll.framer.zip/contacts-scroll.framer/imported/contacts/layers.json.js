window.__imported__ = window.__imported__ || {};
window.__imported__["contacts/layers.json.js"] = [
  {
    "maskFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 1080,
      "height" : 1920
    },
    "id" : "DD49164D-0552-409F-A9F6-45C4AB1A7ED2",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "021EFA63-6F65-4ECD-AF87-CC4D42396B4D",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "6AD61AC2-385C-4E8E-AB5D-513DDF3B3909",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : {
                  "y" : 15,
                  "x" : 906,
                  "width" : 25,
                  "height" : 39
                },
                "id" : "CF03A6DD-5186-4A8A-A229-E8A6AECC5CC3",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-iconBattery-CF03A6DD-5186-4A8A-A229-E8A6AECC5CC3.png",
                  "frame" : {
                    "y" : 15,
                    "x" : 906,
                    "width" : 25,
                    "height" : 39
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 15,
                  "x" : 906,
                  "width" : 25,
                  "height" : 39
                },
                "name" : "iconBattery"
              },
              {
                "maskFrame" : {
                  "y" : 18,
                  "x" : 828,
                  "width" : 37,
                  "height" : 36
                },
                "id" : "9F71E513-4272-40DC-894C-2A7D91A87B35",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-iconReception-9F71E513-4272-40DC-894C-2A7D91A87B35.png",
                  "frame" : {
                    "y" : 18,
                    "x" : 828,
                    "width" : 37,
                    "height" : 36
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 18,
                  "x" : 828,
                  "width" : 37,
                  "height" : 36
                },
                "name" : "iconReception"
              },
              {
                "maskFrame" : {
                  "y" : 18,
                  "x" : 750,
                  "width" : 49,
                  "height" : 36
                },
                "id" : "35E3EB7C-8EA7-4853-ACD6-88767E58ECAC",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-iconWifi-35E3EB7C-8EA7-4853-ACD6-88767E58ECAC.png",
                  "frame" : {
                    "y" : 18,
                    "x" : 750,
                    "width" : 49,
                    "height" : 36
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 18,
                  "x" : 750,
                  "width" : 49,
                  "height" : 36
                },
                "name" : "iconWifi"
              }
            ],
            "image" : {
              "path" : "images\/Layer-statusBarContent-6AD61AC2-385C-4E8E-AB5D-513DDF3B3909.png",
              "frame" : {
                "y" : 15,
                "x" : 750,
                "width" : 302,
                "height" : 39
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 15,
              "x" : 750,
              "width" : 302,
              "height" : 39
            },
            "name" : "statusBarContent"
          }
        ],
        "image" : {
          "path" : "images\/Layer-statusBar-021EFA63-6F65-4ECD-AF87-CC4D42396B4D.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 1080,
            "height" : 72
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 1080,
          "height" : 72
        },
        "name" : "statusBar"
      },
      {
        "maskFrame" : null,
        "id" : "B271B6D0-FE37-4224-8C95-089F3F8DB70E",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "5113B428-5F25-4EE0-9509-5233D740F8F7",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-iconArrow-5113B428-5F25-4EE0-9509-5233D740F8F7.png",
              "frame" : {
                "y" : 150,
                "x" : 444,
                "width" : 30,
                "height" : 15
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 150,
              "x" : 444,
              "width" : 30,
              "height" : 15
            },
            "name" : "iconArrow"
          },
          {
            "maskFrame" : null,
            "id" : "82EA8FB7-6A09-4DDD-BBD1-EE776FF70292",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-iconMore-82EA8FB7-6A09-4DDD-BBD1-EE776FF70292.png",
              "frame" : {
                "y" : 132,
                "x" : 1008,
                "width" : 12,
                "height" : 48
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 132,
              "x" : 1008,
              "width" : 12,
              "height" : 48
            },
            "name" : "iconMore"
          },
          {
            "maskFrame" : null,
            "id" : "5631EECB-EDB8-4F04-9290-2038A89064DE",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-iconSearch-5631EECB-EDB8-4F04-9290-2038A89064DE.png",
              "frame" : {
                "y" : 129,
                "x" : 861,
                "width" : 53,
                "height" : 53
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 129,
              "x" : 861,
              "width" : 53,
              "height" : 53
            },
            "name" : "iconSearch"
          },
          {
            "maskFrame" : null,
            "id" : "7E657B17-672B-45D8-9CBE-CEE2891DD7E0",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-iconMenu-7E657B17-672B-45D8-9CBE-CEE2891DD7E0.png",
              "frame" : {
                "y" : 138,
                "x" : 57,
                "width" : 54,
                "height" : 36
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 138,
              "x" : 57,
              "width" : 54,
              "height" : 36
            },
            "name" : "iconMenu"
          }
        ],
        "image" : {
          "path" : "images\/Layer-appBar-B271B6D0-FE37-4224-8C95-089F3F8DB70E.png",
          "frame" : {
            "y" : -12,
            "x" : -12,
            "width" : 1104,
            "height" : 276
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : -12,
          "x" : -12,
          "width" : 1104,
          "height" : 276
        },
        "name" : "appBar"
      },
      {
        "maskFrame" : null,
        "id" : "9D57D8C3-CBCF-471E-83A9-0732E5447D2A",
        "visible" : false,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-indicator-9D57D8C3-CBCF-471E-83A9-0732E5447D2A.png",
          "frame" : {
            "y" : 620,
            "x" : 650,
            "width" : 440,
            "height" : 440
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 620,
          "x" : 650,
          "width" : 440,
          "height" : 440
        },
        "name" : "indicator"
      },
      {
        "maskFrame" : null,
        "id" : "CFAB92CE-C9B2-4D5C-94D5-900AFBC40748",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-navBar-CFAB92CE-C9B2-4D5C-94D5-900AFBC40748.png",
          "frame" : {
            "y" : 1776,
            "x" : 0,
            "width" : 1080,
            "height" : 144
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 1776,
          "x" : 0,
          "width" : 1080,
          "height" : 144
        },
        "name" : "navBar"
      },
      {
        "maskFrame" : null,
        "children" : [
          {
            "maskFrame" : {
              "y" : 240,
              "x" : 0,
              "width" : 1080,
              "height" : 1537
            },
            "id" : "A99FDC7C-EC7F-4618-8FFA-3FD6E5E3D8A6",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-mask-A99FDC7C-EC7F-4618-8FFA-3FD6E5E3D8A6.png",
              "frame" : {
                "y" : 240,
                "x" : 0,
                "width" : 1080,
                "height" : 1537
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 240,
              "x" : 0,
              "width" : 1080,
              "height" : 1537
            },
            "name" : "mask"
          }
        ],
        "id" : "6CDF6F28-B58A-4DC8-81E3-C1A4E200E940",
        "visible" : true,
        "imageType" : "png",
        "layerFrame" : {
          "y" : 240,
          "x" : 0,
          "width" : 1080,
          "height" : 1537
        },
        "name" : "content"
      }
    ],
    "image" : {
      "path" : "images\/Layer-screen-DD49164D-0552-409F-A9F6-45C4AB1A7ED2.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 1080,
        "height" : 1920
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 1080,
      "height" : 1920
    },
    "name" : "screen"
  }
]