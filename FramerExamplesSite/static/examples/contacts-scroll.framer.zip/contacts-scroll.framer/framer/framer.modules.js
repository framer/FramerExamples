require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"contacts":[function(require,module,exports){
exports.people = {
  A: {
    names: ["Aaron Carámbula", "Adam Michela", "Adria Jimenez", "Andy Ngo"],
    images: ["images/aaron.png", "images/adam.png", "images/adria.png", "images/andy.png"]
  },
  B: {
    names: ["Ben Adamson", "Benjamin den Boer", "Blaise DiPersia", "Brandon Souba"],
    images: ["images/ben2.png", "images/ben.png", "images/blaise.png", "images/brandon.png"]
  },
  C: {
    names: ["Carlos Albertos", "Cemre Güngör", "Christian Baroni", "Christophe Tauziet"],
    images: ["images/carlos.png", "images/cemre.png", "images/christian.png", "images/christophe.png"]
  },
  D: {
    names: ["Daniël van der Winden", "David Lee", "David van Leeuwen", "Dominik Wiegand"],
    images: ["images/daniel.png", "images/david.png", "images/david2.png", "images/dominik.png"]
  },
  E: {
    names: ["Ed Chao", "Edward Sanchez", "Edwin van Rijkom", "Elliott Kember"],
    images: ["images/ed.png", "images/edward.png", "images/edwin.png", "images/elliott.png"]
  },
  F: {
    names: ["Fabrizio Bellomo", "Florian Ludwig", "Floris Verloop", "Fran Pérez"],
    images: ["images/fabrizio.png", "images/florian.png", "images/floris.png", "images/fran.png"]
  },
  G: {
    names: ["Gavin McFarland", "Geoff Teehan", "George Kedenburg III", "Giel Cobben"],
    images: ["images/gavin.png", "images/geoff.png", "images/george.png", "images/giel.png"]
  }
};



},{}]},{},[])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCIvVXNlcnMvR2llbC9DbG91ZC9GcmFtZXIvMS4gV2Vic2l0ZS8zLiBFeGFtcGxlcy9OZXcgRXhhbXBsZXMvX05ldy9jb250YWN0cy1zY3JvbGwuZnJhbWVyL21vZHVsZXMvY29udGFjdHMuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQ0EsT0FBTyxDQUFDLE1BQVIsR0FBaUI7QUFBQSxFQUNoQixDQUFBLEVBQUk7QUFBQSxJQUNILEtBQUEsRUFBTyxDQUFFLGlCQUFGLEVBQXFCLGNBQXJCLEVBQXFDLGVBQXJDLEVBQXNELFVBQXRELENBREo7QUFBQSxJQUVILE1BQUEsRUFBUSxDQUFFLGtCQUFGLEVBQXNCLGlCQUF0QixFQUF5QyxrQkFBekMsRUFBNkQsaUJBQTdELENBRkw7R0FEWTtBQUFBLEVBS2hCLENBQUEsRUFBSTtBQUFBLElBQ0gsS0FBQSxFQUFPLENBQUUsYUFBRixFQUFpQixtQkFBakIsRUFBc0MsaUJBQXRDLEVBQXlELGVBQXpELENBREo7QUFBQSxJQUVILE1BQUEsRUFBUSxDQUFHLGlCQUFILEVBQXNCLGdCQUF0QixFQUF3QyxtQkFBeEMsRUFBNkQsb0JBQTdELENBRkw7R0FMWTtBQUFBLEVBU2hCLENBQUEsRUFBSTtBQUFBLElBQ0gsS0FBQSxFQUFPLENBQUUsaUJBQUYsRUFBcUIsY0FBckIsRUFBcUMsa0JBQXJDLEVBQXlELG9CQUF6RCxDQURKO0FBQUEsSUFFSCxNQUFBLEVBQVEsQ0FBRSxtQkFBRixFQUF1QixrQkFBdkIsRUFBMkMsc0JBQTNDLEVBQW1FLHVCQUFuRSxDQUZMO0dBVFk7QUFBQSxFQWFoQixDQUFBLEVBQUk7QUFBQSxJQUNILEtBQUEsRUFBTyxDQUFFLHVCQUFGLEVBQTJCLFdBQTNCLEVBQXdDLG1CQUF4QyxFQUE2RCxpQkFBN0QsQ0FESjtBQUFBLElBRUgsTUFBQSxFQUFRLENBQUUsbUJBQUYsRUFBdUIsa0JBQXZCLEVBQTJDLG1CQUEzQyxFQUFnRSxvQkFBaEUsQ0FGTDtHQWJZO0FBQUEsRUFpQmhCLENBQUEsRUFBSTtBQUFBLElBQ0gsS0FBQSxFQUFPLENBQUUsU0FBRixFQUFhLGdCQUFiLEVBQStCLGtCQUEvQixFQUFtRCxnQkFBbkQsQ0FESjtBQUFBLElBRUgsTUFBQSxFQUFRLENBQUUsZUFBRixFQUFtQixtQkFBbkIsRUFBd0Msa0JBQXhDLEVBQTRELG9CQUE1RCxDQUZMO0dBakJZO0FBQUEsRUFxQmhCLENBQUEsRUFBSTtBQUFBLElBQ0gsS0FBQSxFQUFPLENBQUUsa0JBQUYsRUFBc0IsZ0JBQXRCLEVBQXdDLGdCQUF4QyxFQUEwRCxZQUExRCxDQURKO0FBQUEsSUFFSCxNQUFBLEVBQVEsQ0FBRSxxQkFBRixFQUF5QixvQkFBekIsRUFBK0MsbUJBQS9DLEVBQW9FLGlCQUFwRSxDQUZMO0dBckJZO0FBQUEsRUF5QmhCLENBQUEsRUFBSTtBQUFBLElBQ0gsS0FBQSxFQUFPLENBQUUsaUJBQUYsRUFBcUIsY0FBckIsRUFBcUMsc0JBQXJDLEVBQTZELGFBQTdELENBREo7QUFBQSxJQUVILE1BQUEsRUFBUSxDQUFFLGtCQUFGLEVBQXNCLGtCQUF0QixFQUEwQyxtQkFBMUMsRUFBK0QsaUJBQS9ELENBRkw7R0F6Qlk7Q0FBakIsQ0FBQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCIjIFBlb3BsZVxuZXhwb3J0cy5wZW9wbGUgPSB7XG5cdEEgOiB7XG5cdFx0bmFtZXM6IFsgXCJBYXJvbiBDYXLDoW1idWxhXCIsIFwiQWRhbSBNaWNoZWxhXCIsIFwiQWRyaWEgSmltZW5lelwiLCBcIkFuZHkgTmdvXCIgXVxuXHRcdGltYWdlczogWyBcImltYWdlcy9hYXJvbi5wbmdcIiwgXCJpbWFnZXMvYWRhbS5wbmdcIiwgXCJpbWFnZXMvYWRyaWEucG5nXCIsIFwiaW1hZ2VzL2FuZHkucG5nXCIgXVxuXHR9XG5cdEIgOiB7XG5cdFx0bmFtZXM6IFsgXCJCZW4gQWRhbXNvblwiLCBcIkJlbmphbWluIGRlbiBCb2VyXCIsIFwiQmxhaXNlIERpUGVyc2lhXCIsIFwiQnJhbmRvbiBTb3ViYVwiXVxuXHRcdGltYWdlczogWyAgXCJpbWFnZXMvYmVuMi5wbmdcIiwgXCJpbWFnZXMvYmVuLnBuZ1wiLCBcImltYWdlcy9ibGFpc2UucG5nXCIsIFwiaW1hZ2VzL2JyYW5kb24ucG5nXCJdXG5cdH1cblx0QyA6IHtcblx0XHRuYW1lczogWyBcIkNhcmxvcyBBbGJlcnRvc1wiLCBcIkNlbXJlIEfDvG5nw7ZyXCIsIFwiQ2hyaXN0aWFuIEJhcm9uaVwiLCBcIkNocmlzdG9waGUgVGF1emlldFwiXVxuXHRcdGltYWdlczogWyBcImltYWdlcy9jYXJsb3MucG5nXCIsIFwiaW1hZ2VzL2NlbXJlLnBuZ1wiLCBcImltYWdlcy9jaHJpc3RpYW4ucG5nXCIsIFwiaW1hZ2VzL2NocmlzdG9waGUucG5nXCIgXVxuXHR9XG5cdEQgOiB7XG5cdFx0bmFtZXM6IFsgXCJEYW5pw6tsIHZhbiBkZXIgV2luZGVuXCIsIFwiRGF2aWQgTGVlXCIsIFwiRGF2aWQgdmFuIExlZXV3ZW5cIiwgXCJEb21pbmlrIFdpZWdhbmRcIl1cblx0XHRpbWFnZXM6IFsgXCJpbWFnZXMvZGFuaWVsLnBuZ1wiLCBcImltYWdlcy9kYXZpZC5wbmdcIiwgXCJpbWFnZXMvZGF2aWQyLnBuZ1wiLCBcImltYWdlcy9kb21pbmlrLnBuZ1wiIF1cblx0fVxuXHRFIDoge1xuXHRcdG5hbWVzOiBbIFwiRWQgQ2hhb1wiLCBcIkVkd2FyZCBTYW5jaGV6XCIsIFwiRWR3aW4gdmFuIFJpamtvbVwiLCBcIkVsbGlvdHQgS2VtYmVyXCJdXG5cdFx0aW1hZ2VzOiBbIFwiaW1hZ2VzL2VkLnBuZ1wiLCBcImltYWdlcy9lZHdhcmQucG5nXCIsIFwiaW1hZ2VzL2Vkd2luLnBuZ1wiLCBcImltYWdlcy9lbGxpb3R0LnBuZ1wiXVxuXHR9XG5cdEYgOiB7XG5cdFx0bmFtZXM6IFsgXCJGYWJyaXppbyBCZWxsb21vXCIsIFwiRmxvcmlhbiBMdWR3aWdcIiwgXCJGbG9yaXMgVmVybG9vcFwiLCBcIkZyYW4gUMOpcmV6XCJdXG5cdFx0aW1hZ2VzOiBbIFwiaW1hZ2VzL2ZhYnJpemlvLnBuZ1wiLCBcImltYWdlcy9mbG9yaWFuLnBuZ1wiLCBcImltYWdlcy9mbG9yaXMucG5nXCIsIFwiaW1hZ2VzL2ZyYW4ucG5nXCIgXVxuXHR9XG5cdEcgOiB7XG5cdFx0bmFtZXM6IFsgXCJHYXZpbiBNY0ZhcmxhbmRcIiwgXCJHZW9mZiBUZWVoYW5cIiwgXCJHZW9yZ2UgS2VkZW5idXJnIElJSVwiLCBcIkdpZWwgQ29iYmVuXCJdXG5cdFx0aW1hZ2VzOiBbIFwiaW1hZ2VzL2dhdmluLnBuZ1wiLCBcImltYWdlcy9nZW9mZi5wbmdcIiwgXCJpbWFnZXMvZ2VvcmdlLnBuZ1wiLCBcImltYWdlcy9naWVsLnBuZ1wiIF1cblx0fVxufSJdfQ==
