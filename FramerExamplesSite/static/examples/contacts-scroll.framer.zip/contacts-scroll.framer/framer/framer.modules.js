require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"contacts":[function(require,module,exports){
exports.people = {
  A: {
    names: ["Aaron Carámbula", "Adam Michela", "Adria Jimenez", "Andy Ngo"],
    images: ["images/aaron.png", "images/adam.png", "images/adria.png", "images/andy.png"]
  },
  B: {
    names: ["Ben Adamson", "Benjamin den Boer", "Blaise DiPersia", "Brandon Souba"],
    images: ["images/ben2.png", "images/ben.png", "images/blaise.png", "images/brandon.png"]
  },
  C: {
    names: ["Carlos Albertos", "Cemre Güngör", "Christian Baroni", "Christophe Tauziet"],
    images: ["images/carlos.png", "images/cemre.png", "images/christian.png", "images/christophe.png"]
  },
  D: {
    names: ["Daniël van der Winden", "David Lee", "David van Leeuwen", "Dominik Wiegand"],
    images: ["images/daniel.png", "images/david.png", "images/david2.png", "images/dominik.png"]
  },
  E: {
    names: ["Ed Chao", "Edward Sanchez", "Edwin van Rijkom", "Elliott Kember"],
    images: ["images/ed.png", "images/edward.png", "images/edwin.png", "images/elliott.png"]
  },
  F: {
    names: ["Fabrizio Bellomo", "Florian Ludwig", "Floris Verloop", "Fran Pérez"],
    images: ["images/fabrizio.png", "images/florian.png", "images/floris.png", "images/fran.png"]
  },
  G: {
    names: ["Gavin McFarland", "Geoff Teehan", "George Kedenburg III", "Giel Cobben"],
    images: ["images/gavin.png", "images/geoff.png", "images/george.png", "images/giel.png"]
  }
};


},{}]},{},[])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCIvVXNlcnMvS3Jpam5SaWpzaG91d2VyL1dlYnNpdGVzL0ZyYW1lckV4YW1wbGVzL0V4YW1wbGVzL2NvbnRhY3RzLXNjcm9sbC5mcmFtZXIvbW9kdWxlcy9jb250YWN0cy5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNDQSxPQUFPLENBQUMsTUFBUixHQUFpQjtFQUNoQixDQUFBLEVBQUk7SUFDSCxLQUFBLEVBQU8sQ0FBRSxpQkFBRixFQUFxQixjQUFyQixFQUFxQyxlQUFyQyxFQUFzRCxVQUF0RCxDQURKO0lBRUgsTUFBQSxFQUFRLENBQUUsa0JBQUYsRUFBc0IsaUJBQXRCLEVBQXlDLGtCQUF6QyxFQUE2RCxpQkFBN0QsQ0FGTDtHQURZO0VBS2hCLENBQUEsRUFBSTtJQUNILEtBQUEsRUFBTyxDQUFFLGFBQUYsRUFBaUIsbUJBQWpCLEVBQXNDLGlCQUF0QyxFQUF5RCxlQUF6RCxDQURKO0lBRUgsTUFBQSxFQUFRLENBQUcsaUJBQUgsRUFBc0IsZ0JBQXRCLEVBQXdDLG1CQUF4QyxFQUE2RCxvQkFBN0QsQ0FGTDtHQUxZO0VBU2hCLENBQUEsRUFBSTtJQUNILEtBQUEsRUFBTyxDQUFFLGlCQUFGLEVBQXFCLGNBQXJCLEVBQXFDLGtCQUFyQyxFQUF5RCxvQkFBekQsQ0FESjtJQUVILE1BQUEsRUFBUSxDQUFFLG1CQUFGLEVBQXVCLGtCQUF2QixFQUEyQyxzQkFBM0MsRUFBbUUsdUJBQW5FLENBRkw7R0FUWTtFQWFoQixDQUFBLEVBQUk7SUFDSCxLQUFBLEVBQU8sQ0FBRSx1QkFBRixFQUEyQixXQUEzQixFQUF3QyxtQkFBeEMsRUFBNkQsaUJBQTdELENBREo7SUFFSCxNQUFBLEVBQVEsQ0FBRSxtQkFBRixFQUF1QixrQkFBdkIsRUFBMkMsbUJBQTNDLEVBQWdFLG9CQUFoRSxDQUZMO0dBYlk7RUFpQmhCLENBQUEsRUFBSTtJQUNILEtBQUEsRUFBTyxDQUFFLFNBQUYsRUFBYSxnQkFBYixFQUErQixrQkFBL0IsRUFBbUQsZ0JBQW5ELENBREo7SUFFSCxNQUFBLEVBQVEsQ0FBRSxlQUFGLEVBQW1CLG1CQUFuQixFQUF3QyxrQkFBeEMsRUFBNEQsb0JBQTVELENBRkw7R0FqQlk7RUFxQmhCLENBQUEsRUFBSTtJQUNILEtBQUEsRUFBTyxDQUFFLGtCQUFGLEVBQXNCLGdCQUF0QixFQUF3QyxnQkFBeEMsRUFBMEQsWUFBMUQsQ0FESjtJQUVILE1BQUEsRUFBUSxDQUFFLHFCQUFGLEVBQXlCLG9CQUF6QixFQUErQyxtQkFBL0MsRUFBb0UsaUJBQXBFLENBRkw7R0FyQlk7RUF5QmhCLENBQUEsRUFBSTtJQUNILEtBQUEsRUFBTyxDQUFFLGlCQUFGLEVBQXFCLGNBQXJCLEVBQXFDLHNCQUFyQyxFQUE2RCxhQUE3RCxDQURKO0lBRUgsTUFBQSxFQUFRLENBQUUsa0JBQUYsRUFBc0Isa0JBQXRCLEVBQTBDLG1CQUExQyxFQUErRCxpQkFBL0QsQ0FGTDtHQXpCWSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCIjIFBlb3BsZVxuZXhwb3J0cy5wZW9wbGUgPSB7XG5cdEEgOiB7XG5cdFx0bmFtZXM6IFsgXCJBYXJvbiBDYXLDoW1idWxhXCIsIFwiQWRhbSBNaWNoZWxhXCIsIFwiQWRyaWEgSmltZW5lelwiLCBcIkFuZHkgTmdvXCIgXVxuXHRcdGltYWdlczogWyBcImltYWdlcy9hYXJvbi5wbmdcIiwgXCJpbWFnZXMvYWRhbS5wbmdcIiwgXCJpbWFnZXMvYWRyaWEucG5nXCIsIFwiaW1hZ2VzL2FuZHkucG5nXCIgXVxuXHR9XG5cdEIgOiB7XG5cdFx0bmFtZXM6IFsgXCJCZW4gQWRhbXNvblwiLCBcIkJlbmphbWluIGRlbiBCb2VyXCIsIFwiQmxhaXNlIERpUGVyc2lhXCIsIFwiQnJhbmRvbiBTb3ViYVwiXVxuXHRcdGltYWdlczogWyAgXCJpbWFnZXMvYmVuMi5wbmdcIiwgXCJpbWFnZXMvYmVuLnBuZ1wiLCBcImltYWdlcy9ibGFpc2UucG5nXCIsIFwiaW1hZ2VzL2JyYW5kb24ucG5nXCJdXG5cdH1cblx0QyA6IHtcblx0XHRuYW1lczogWyBcIkNhcmxvcyBBbGJlcnRvc1wiLCBcIkNlbXJlIEfDvG5nw7ZyXCIsIFwiQ2hyaXN0aWFuIEJhcm9uaVwiLCBcIkNocmlzdG9waGUgVGF1emlldFwiXVxuXHRcdGltYWdlczogWyBcImltYWdlcy9jYXJsb3MucG5nXCIsIFwiaW1hZ2VzL2NlbXJlLnBuZ1wiLCBcImltYWdlcy9jaHJpc3RpYW4ucG5nXCIsIFwiaW1hZ2VzL2NocmlzdG9waGUucG5nXCIgXVxuXHR9XG5cdEQgOiB7XG5cdFx0bmFtZXM6IFsgXCJEYW5pw6tsIHZhbiBkZXIgV2luZGVuXCIsIFwiRGF2aWQgTGVlXCIsIFwiRGF2aWQgdmFuIExlZXV3ZW5cIiwgXCJEb21pbmlrIFdpZWdhbmRcIl1cblx0XHRpbWFnZXM6IFsgXCJpbWFnZXMvZGFuaWVsLnBuZ1wiLCBcImltYWdlcy9kYXZpZC5wbmdcIiwgXCJpbWFnZXMvZGF2aWQyLnBuZ1wiLCBcImltYWdlcy9kb21pbmlrLnBuZ1wiIF1cblx0fVxuXHRFIDoge1xuXHRcdG5hbWVzOiBbIFwiRWQgQ2hhb1wiLCBcIkVkd2FyZCBTYW5jaGV6XCIsIFwiRWR3aW4gdmFuIFJpamtvbVwiLCBcIkVsbGlvdHQgS2VtYmVyXCJdXG5cdFx0aW1hZ2VzOiBbIFwiaW1hZ2VzL2VkLnBuZ1wiLCBcImltYWdlcy9lZHdhcmQucG5nXCIsIFwiaW1hZ2VzL2Vkd2luLnBuZ1wiLCBcImltYWdlcy9lbGxpb3R0LnBuZ1wiXVxuXHR9XG5cdEYgOiB7XG5cdFx0bmFtZXM6IFsgXCJGYWJyaXppbyBCZWxsb21vXCIsIFwiRmxvcmlhbiBMdWR3aWdcIiwgXCJGbG9yaXMgVmVybG9vcFwiLCBcIkZyYW4gUMOpcmV6XCJdXG5cdFx0aW1hZ2VzOiBbIFwiaW1hZ2VzL2ZhYnJpemlvLnBuZ1wiLCBcImltYWdlcy9mbG9yaWFuLnBuZ1wiLCBcImltYWdlcy9mbG9yaXMucG5nXCIsIFwiaW1hZ2VzL2ZyYW4ucG5nXCIgXVxuXHR9XG5cdEcgOiB7XG5cdFx0bmFtZXM6IFsgXCJHYXZpbiBNY0ZhcmxhbmRcIiwgXCJHZW9mZiBUZWVoYW5cIiwgXCJHZW9yZ2UgS2VkZW5idXJnIElJSVwiLCBcIkdpZWwgQ29iYmVuXCJdXG5cdFx0aW1hZ2VzOiBbIFwiaW1hZ2VzL2dhdmluLnBuZ1wiLCBcImltYWdlcy9nZW9mZi5wbmdcIiwgXCJpbWFnZXMvZ2VvcmdlLnBuZ1wiLCBcImltYWdlcy9naWVsLnBuZ1wiIF1cblx0fVxufSJdfQ==
