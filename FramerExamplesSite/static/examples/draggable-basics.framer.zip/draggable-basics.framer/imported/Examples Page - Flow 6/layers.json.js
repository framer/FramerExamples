window.__imported__ = window.__imported__ || {};
window.__imported__["Examples Page - Flow 6/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "F7DAB72F-EB40-4CA1-8500-D9CF9C762AF2",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Group_2-F7DAB72F-EB40-4CA1-8500-D9CF9C762AF2.png",
      "frame" : {
        "y" : 1831,
        "x" : 800,
        "width" : 250,
        "height" : 32
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 1831,
      "x" : 800,
      "width" : 250,
      "height" : 32
    },
    "name" : "Group_2"
  },
  {
    "maskFrame" : null,
    "id" : "10A6DCC6-ECEC-4226-B2E0-335078FD9C55",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "E8F814C4-0AE3-4CF2-9B3D-D078E6A02259",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Group_6-E8F814C4-0AE3-4CF2-9B3D-D078E6A02259.png",
          "frame" : {
            "y" : 4060,
            "x" : 1866,
            "width" : 662,
            "height" : 518
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 4060,
          "x" : 1866,
          "width" : 662,
          "height" : 518
        },
        "name" : "Group_6"
      }
    ],
    "image" : {
      "path" : "images\/Rectangle_315__Group_8-10A6DCC6-ECEC-4226-B2E0-335078FD9C55.png",
      "frame" : {
        "y" : 4060,
        "x" : 1866,
        "width" : 662,
        "height" : 518
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 4060,
      "x" : 1866,
      "width" : 662,
      "height" : 518
    },
    "name" : "Rectangle_315__Group_8"
  },
  {
    "maskFrame" : {
      "y" : 450,
      "x" : 840,
      "width" : 210,
      "height" : 210
    },
    "id" : "1C24D2A4-B545-4BFC-AE61-406D30F2666F",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_153-1C24D2A4-B545-4BFC-AE61-406D30F2666F.png",
      "frame" : {
        "y" : 450,
        "x" : 840,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 450,
      "x" : 840,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_153"
  },
  {
    "maskFrame" : {
      "y" : 450,
      "x" : 30,
      "width" : 210,
      "height" : 210
    },
    "id" : "E6CD4E1A-28AF-4EF5-91BC-7244218D7C3B",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_154-E6CD4E1A-28AF-4EF5-91BC-7244218D7C3B.png",
      "frame" : {
        "y" : 450,
        "x" : 30,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 450,
      "x" : 30,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_154"
  },
  {
    "maskFrame" : null,
    "id" : "C76F4ED6-B3B9-4180-B69F-B18EE75F9B0B",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap_4__Rectangle_213-C76F4ED6-B3B9-4180-B69F-B18EE75F9B0B.png",
      "frame" : {
        "y" : 12,
        "x" : 3923,
        "width" : 687,
        "height" : 722
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 12,
      "x" : 3923,
      "width" : 687,
      "height" : 722
    },
    "name" : "Bitmap_4__Rectangle_213"
  },
  {
    "maskFrame" : {
      "y" : 450,
      "x" : 570,
      "width" : 210,
      "height" : 210
    },
    "id" : "F6E1AD71-DCF7-4A70-99F9-7164A8E5CDC6",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_73-F6E1AD71-DCF7-4A70-99F9-7164A8E5CDC6.png",
      "frame" : {
        "y" : 450,
        "x" : 570,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 450,
      "x" : 570,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_73"
  },
  {
    "maskFrame" : {
      "y" : 145,
      "x" : 570,
      "width" : 210,
      "height" : 210
    },
    "id" : "D7B1DA27-50CA-439A-B3A9-FAEC54FBB3E7",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_74-D7B1DA27-50CA-439A-B3A9-FAEC54FBB3E7.png",
      "frame" : {
        "y" : 145,
        "x" : 570,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 145,
      "x" : 570,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_74"
  },
  {
    "maskFrame" : {
      "y" : 755,
      "x" : 840,
      "width" : 210,
      "height" : 210
    },
    "id" : "9FC542D8-9D96-4CE6-B43E-5DC33BE01A69",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_76-9FC542D8-9D96-4CE6-B43E-5DC33BE01A69.png",
      "frame" : {
        "y" : 755,
        "x" : 840,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 755,
      "x" : 840,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_76"
  },
  {
    "maskFrame" : {
      "y" : 756,
      "x" : 300,
      "width" : 210,
      "height" : 210
    },
    "id" : "86F06BE7-FCC9-4D4C-AF11-42B801994395",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_77-86F06BE7-FCC9-4D4C-AF11-42B801994395.png",
      "frame" : {
        "y" : 756,
        "x" : 300,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 756,
      "x" : 300,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_77"
  },
  {
    "maskFrame" : {
      "y" : 754,
      "x" : 30,
      "width" : 210,
      "height" : 210
    },
    "id" : "61D28120-64CD-4E1F-B909-2BE567663B29",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_78-61D28120-64CD-4E1F-B909-2BE567663B29.png",
      "frame" : {
        "y" : 754,
        "x" : 30,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 754,
      "x" : 30,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_78"
  },
  {
    "maskFrame" : {
      "y" : 1064,
      "x" : 570,
      "width" : 210,
      "height" : 210
    },
    "id" : "15843704-A20F-4A68-BB6D-E2599F584A2E",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_80-15843704-A20F-4A68-BB6D-E2599F584A2E.png",
      "frame" : {
        "y" : 1064,
        "x" : 570,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 1064,
      "x" : 570,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_80"
  },
  {
    "maskFrame" : {
      "y" : 1064,
      "x" : 840,
      "width" : 210,
      "height" : 210
    },
    "id" : "0A35BA91-E7A8-4301-B524-327EAA58DB33",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_81-0A35BA91-E7A8-4301-B524-327EAA58DB33.png",
      "frame" : {
        "y" : 1064,
        "x" : 840,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 1064,
      "x" : 840,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_81"
  },
  {
    "maskFrame" : {
      "y" : 757,
      "x" : 570,
      "width" : 210,
      "height" : 210
    },
    "id" : "95D26D68-067C-4E2E-A3AE-92C6556D38C5",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_83-95D26D68-067C-4E2E-A3AE-92C6556D38C5.png",
      "frame" : {
        "y" : 757,
        "x" : 570,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 757,
      "x" : 570,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_83"
  },
  {
    "maskFrame" : {
      "y" : 1367,
      "x" : 300,
      "width" : 210,
      "height" : 210
    },
    "id" : "408B8359-04F3-44AA-86EE-CECFE1B8AF16",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_82-408B8359-04F3-44AA-86EE-CECFE1B8AF16.png",
      "frame" : {
        "y" : 1367,
        "x" : 300,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 1367,
      "x" : 300,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_82"
  },
  {
    "maskFrame" : {
      "y" : 450,
      "x" : 300,
      "width" : 210,
      "height" : 210
    },
    "id" : "A026875C-5BCD-41D9-A8DB-A4E920E7E48E",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_145-A026875C-5BCD-41D9-A8DB-A4E920E7E48E.png",
      "frame" : {
        "y" : 450,
        "x" : 300,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 450,
      "x" : 300,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_145"
  },
  {
    "maskFrame" : null,
    "id" : "A764F2F3-1842-406B-A930-8345BA56913A",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Group-A764F2F3-1842-406B-A930-8345BA56913A.png",
      "frame" : {
        "y" : -255,
        "x" : 1757,
        "width" : 32,
        "height" : 24
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : -255,
      "x" : 1757,
      "width" : 32,
      "height" : 24
    },
    "name" : "Group"
  },
  {
    "maskFrame" : null,
    "id" : "C7CDCE69-4A96-4BDF-A551-05801EED6322",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Group_3-C7CDCE69-4A96-4BDF-A551-05801EED6322.png",
      "frame" : {
        "y" : 1092,
        "x" : 3029,
        "width" : 32,
        "height" : 24
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 1092,
      "x" : 3029,
      "width" : 32,
      "height" : 24
    },
    "name" : "Group_3"
  },
  {
    "maskFrame" : {
      "y" : 146,
      "x" : 30,
      "width" : 210,
      "height" : 210
    },
    "id" : "2D8D6B50-A14D-49B3-99C3-E67A609E8B87",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_151-2D8D6B50-A14D-49B3-99C3-E67A609E8B87.png",
      "frame" : {
        "y" : 146,
        "x" : 30,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 146,
      "x" : 30,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_151"
  },
  {
    "maskFrame" : {
      "y" : 145,
      "x" : 840,
      "width" : 210,
      "height" : 210
    },
    "id" : "3A6DA0CE-8395-499F-ADC3-F1945B170733",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_150-3A6DA0CE-8395-499F-ADC3-F1945B170733.png",
      "frame" : {
        "y" : 145,
        "x" : 840,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 145,
      "x" : 840,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_150"
  },
  {
    "maskFrame" : null,
    "id" : "F72EDF05-9223-481A-BBA6-F111382ED985",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Path_17__Path_18-F72EDF05-9223-481A-BBA6-F111382ED985.png",
      "frame" : {
        "y" : -31,
        "x" : 3174,
        "width" : 10,
        "height" : 10
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : -31,
      "x" : 3174,
      "width" : 10,
      "height" : 10
    },
    "name" : "Path_17__Path_18"
  },
  {
    "maskFrame" : {
      "y" : 145,
      "x" : 300,
      "width" : 210,
      "height" : 210
    },
    "id" : "F1F69BE6-7DF8-4974-B52E-2000D4C1D937",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_75-F1F69BE6-7DF8-4974-B52E-2000D4C1D937.png",
      "frame" : {
        "y" : 145,
        "x" : 300,
        "width" : 210,
        "height" : 210
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 145,
      "x" : 300,
      "width" : 210,
      "height" : 210
    },
    "name" : "Bitmap__Rectangle_148__CAROUSEL__Dropbox__Oval_3__Path_71__Path_75"
  },
  {
    "maskFrame" : null,
    "id" : "D9A2C473-724E-44BF-9111-BF5D6DF39053",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/iconseecode__Path_18__Path_20-D9A2C473-724E-44BF-9111-BF5D6DF39053.png",
      "frame" : {
        "y" : -42,
        "x" : 1466,
        "width" : 24,
        "height" : 24
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : -42,
      "x" : 1466,
      "width" : 24,
      "height" : 24
    },
    "name" : "iconseecode__Path_18__Path_20"
  },
  {
    "maskFrame" : null,
    "id" : "1256AA6D-C2FD-448F-B45B-E10220947F38",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "A0B40C3A-C182-478B-B4CE-7DBA23AF6C95",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Rectangle_313__Rectangle_314-A0B40C3A-C182-478B-B4CE-7DBA23AF6C95.png",
          "frame" : {
            "y" : 73,
            "x" : 972,
            "width" : 8,
            "height" : 8
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 73,
          "x" : 972,
          "width" : 8,
          "height" : 8
        },
        "name" : "Rectangle_313__Rectangle_314"
      }
    ],
    "image" : {
      "path" : "images\/Oval_26__Rectangle_313__Rectangle_314-1256AA6D-C2FD-448F-B45B-E10220947F38.png",
      "frame" : {
        "y" : 62,
        "x" : 961,
        "width" : 92,
        "height" : 29
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 62,
      "x" : 961,
      "width" : 92,
      "height" : 29
    },
    "name" : "Oval_26__Rectangle_313__Rectangle_314"
  }
]