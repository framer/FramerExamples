Example Readme

# Framer Studio

Examples have been made with Framer Studio. If you do not have Framer Studio,
you can download a free trial here: http://framerjs.com

# Working with the standalone Framer.js library

If you prefer working with the standalone framer.js library, include
the included app.js file within your index.html file to make changes. 
Learn more about working with Framer.js on GitHub: https://github.com/koenbok/Framer

