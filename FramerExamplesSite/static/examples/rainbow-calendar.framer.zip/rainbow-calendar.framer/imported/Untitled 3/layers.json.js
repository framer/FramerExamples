window.__imported__ = window.__imported__ || {};
window.__imported__["Untitled 3/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "5D6F3141-6667-42D2-8362-E6276ACEF568",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "3F584AED-F6AA-4AE0-B8CF-F85E3B3DCBB5",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/BG_26-3F584AED-F6AA-4AE0-B8CF-F85E3B3DCBB5.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 640,
            "height" : 1136
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 640,
          "height" : 1136
        },
        "name" : "BG_26"
      }
    ],
    "image" : {
      "path" : "images\/Portrait__55S5C-5D6F3141-6667-42D2-8362-E6276ACEF568.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 640,
        "height" : 1136
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 640,
      "height" : 1136
    },
    "name" : "Portrait__55S5C"
  }
]