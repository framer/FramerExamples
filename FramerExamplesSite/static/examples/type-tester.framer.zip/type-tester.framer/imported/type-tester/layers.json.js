window.__imported__ = window.__imported__ || {};
window.__imported__["type-tester/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "3AF655BB-EF71-4027-ADEE-02DBFE5B89F7",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "5FCE65B7-8C86-443D-90AD-1106EED6649D",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "BF9BC5FB-E545-4218-840C-47BF6EE9A2D1",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "544BDD49-EFF6-4158-8D1F-7F22F648708B",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/Layer-Battery-544BDD49-EFF6-4158-8D1F-7F22F648708B.png",
                      "frame" : {
                        "y" : 11,
                        "x" : 690,
                        "width" : 49,
                        "height" : 19
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 11,
                      "x" : 690,
                      "width" : 49,
                      "height" : 19
                    },
                    "name" : "Battery"
                  }
                ],
                "image" : {
                  "path" : "images\/Layer-statusBar-BF9BC5FB-E545-4218-840C-47BF6EE9A2D1.png",
                  "frame" : {
                    "y" : 11,
                    "x" : 13,
                    "width" : 726,
                    "height" : 20
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 11,
                  "x" : 13,
                  "width" : 726,
                  "height" : 20
                },
                "name" : "statusBar"
              }
            ],
            "image" : {
              "path" : "images\/Layer-navBarContent-5FCE65B7-8C86-443D-90AD-1106EED6649D.png",
              "frame" : {
                "y" : 11,
                "x" : 13,
                "width" : 726,
                "height" : 91
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 11,
              "x" : 13,
              "width" : 726,
              "height" : 91
            },
            "name" : "navBarContent"
          },
          {
            "maskFrame" : null,
            "id" : "C20C9E01-685D-4C81-87D3-3079E6132A66",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-navBarBackground-C20C9E01-685D-4C81-87D3-3079E6132A66.png",
              "frame" : {
                "y" : 0,
                "x" : 0,
                "width" : 750,
                "height" : 128
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 0,
              "x" : 0,
              "width" : 750,
              "height" : 128
            },
            "name" : "navBarBackground"
          },
          {
            "maskFrame" : null,
            "id" : "3064B5F5-D50D-4755-842F-467E8D0B7E6F",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-textBackground-3064B5F5-D50D-4755-842F-467E8D0B7E6F.png",
              "frame" : {
                "y" : 0,
                "x" : 0,
                "width" : 750,
                "height" : 866
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 0,
              "x" : 0,
              "width" : 750,
              "height" : 866
            },
            "name" : "textBackground"
          }
        ],
        "id" : "210B5F3E-EDDA-45FE-A169-7E30A1029393",
        "visible" : true,
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 866
        },
        "name" : "navBar"
      },
      {
        "maskFrame" : null,
        "id" : "715C53D4-B842-49DF-AA07-5FF15B10C37E",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-labels-715C53D4-B842-49DF-AA07-5FF15B10C37E.png",
          "frame" : {
            "y" : 975,
            "x" : 61,
            "width" : 91,
            "height" : 260
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 975,
          "x" : 61,
          "width" : 91,
          "height" : 260
        },
        "name" : "labels"
      }
    ],
    "image" : {
      "path" : "images\/Layer-screen-3AF655BB-EF71-4027-ADEE-02DBFE5B89F7.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "screen"
  },
  {
    "maskFrame" : null,
    "id" : "AD32F2FE-BB39-4846-8002-07A6B0430C61",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-indicator-AD32F2FE-BB39-4846-8002-07A6B0430C61.png",
      "frame" : {
        "y" : 0,
        "x" : 840,
        "width" : 100,
        "height" : 120
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 840,
      "width" : 100,
      "height" : 120
    },
    "name" : "indicator"
  }
]