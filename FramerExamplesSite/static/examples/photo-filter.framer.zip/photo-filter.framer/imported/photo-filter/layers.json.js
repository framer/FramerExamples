window.__imported__ = window.__imported__ || {};
window.__imported__["photo-filter/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "3AF655BB-EF71-4027-ADEE-02DBFE5B89F7",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "210B5F3E-EDDA-45FE-A169-7E30A1029393",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "5FCE65B7-8C86-443D-90AD-1106EED6649D",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "BF9BC5FB-E545-4218-840C-47BF6EE9A2D1",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "544BDD49-EFF6-4158-8D1F-7F22F648708B",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/Layer-Battery-544BDD49-EFF6-4158-8D1F-7F22F648708B.png",
                      "frame" : {
                        "y" : 11,
                        "x" : 690,
                        "width" : 49,
                        "height" : 19
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 11,
                      "x" : 690,
                      "width" : 49,
                      "height" : 19
                    },
                    "name" : "Battery"
                  }
                ],
                "image" : {
                  "path" : "images\/Layer-statusBar-BF9BC5FB-E545-4218-840C-47BF6EE9A2D1.png",
                  "frame" : {
                    "y" : 11,
                    "x" : 13,
                    "width" : 726,
                    "height" : 20
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 11,
                  "x" : 13,
                  "width" : 726,
                  "height" : 20
                },
                "name" : "statusBar"
              }
            ],
            "image" : {
              "path" : "images\/Layer-navBarContent-5FCE65B7-8C86-443D-90AD-1106EED6649D.png",
              "frame" : {
                "y" : 11,
                "x" : 13,
                "width" : 726,
                "height" : 85
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 11,
              "x" : 13,
              "width" : 726,
              "height" : 85
            },
            "name" : "navBarContent"
          }
        ],
        "image" : {
          "path" : "images\/Layer-navBar-210B5F3E-EDDA-45FE-A169-7E30A1029393.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 128
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 128
        },
        "name" : "navBar"
      },
      {
        "maskFrame" : null,
        "children" : [
          {
            "maskFrame" : {
              "y" : 161,
              "x" : 32,
              "width" : 688,
              "height" : 688
            },
            "id" : "9BCA4466-E662-4FA8-B109-2C36903A03FD",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-photo-9BCA4466-E662-4FA8-B109-2C36903A03FD.png",
              "frame" : {
                "y" : 161,
                "x" : 32,
                "width" : 688,
                "height" : 688
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 161,
              "x" : 32,
              "width" : 688,
              "height" : 688
            },
            "name" : "photo"
          }
        ],
        "id" : "E7175CC5-2887-41E1-A3AE-2E7535CC161D",
        "visible" : true,
        "imageType" : "png",
        "layerFrame" : {
          "y" : 161,
          "x" : 32,
          "width" : 688,
          "height" : 688
        },
        "name" : "content"
      },
      {
        "maskFrame" : null,
        "id" : "715C53D4-B842-49DF-AA07-5FF15B10C37E",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-labels-715C53D4-B842-49DF-AA07-5FF15B10C37E.png",
          "frame" : {
            "y" : 975,
            "x" : 34,
            "width" : 118,
            "height" : 256
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 975,
          "x" : 34,
          "width" : 118,
          "height" : 256
        },
        "name" : "labels"
      }
    ],
    "image" : {
      "path" : "images\/Layer-screen-3AF655BB-EF71-4027-ADEE-02DBFE5B89F7.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "screen"
  }
]