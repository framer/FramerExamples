window.__imported__ = window.__imported__ || {};
window.__imported__["shuffle/layers.json.js"] = [
  {
    "maskFrame" : null,
    "visible" : true,
    "id" : "BDA10850-0078-486C-A884-C87DBDE2C1C2",
    "children" : [
      {
        "maskFrame" : null,
        "visible" : true,
        "id" : "079F4452-3F8A-4F43-A762-DB1531BCD3CB",
        "children" : [
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "20A277CC-2701-4352-A2D2-87FD0C5C7A3F",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "C9FF284F-6231-4949-BBBD-B2D6C2036F5F",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/guide-C9FF284F-6231-4949-BBBD-B2D6C2036F5F.png",
                  "frame" : {
                    "y" : 205,
                    "x" : 172,
                    "width" : 480,
                    "height" : 393
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 205,
                  "x" : 172,
                  "width" : 480,
                  "height" : 393
                },
                "name" : "guide"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "4BD495D1-F5A7-479B-AFEA-4E9A59869656",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/guide-4BD495D1-F5A7-479B-AFEA-4E9A59869656.png",
                  "frame" : {
                    "y" : 36,
                    "x" : 234,
                    "width" : 421,
                    "height" : 393
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 36,
                  "x" : 234,
                  "width" : 421,
                  "height" : 393
                },
                "name" : "guide"
              }
            ],
            "image" : {
              "path" : "images\/Group_2-20A277CC-2701-4352-A2D2-87FD0C5C7A3F.png",
              "frame" : {
                "y" : 36,
                "x" : 172,
                "width" : 483,
                "height" : 562
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 36,
              "x" : 172,
              "width" : 483,
              "height" : 562
            },
            "name" : "Group_2"
          }
        ],
        "image" : {
          "path" : "images\/shuffle-079F4452-3F8A-4F43-A762-DB1531BCD3CB.png",
          "frame" : {
            "y" : -1,
            "x" : -1,
            "width" : 802,
            "height" : 602
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : -1,
          "x" : -1,
          "width" : 802,
          "height" : 602
        },
        "name" : "shuffle"
      },
      {
        "maskFrame" : null,
        "visible" : true,
        "id" : "051E7559-60FD-4949-BFCE-B5395FE0FD05",
        "children" : [

        ],
        "image" : {
          "path" : "images\/Group_3-051E7559-60FD-4949-BFCE-B5395FE0FD05.png",
          "frame" : {
            "y" : 54,
            "x" : 101,
            "width" : 553,
            "height" : 560
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 54,
          "x" : 101,
          "width" : 553,
          "height" : 560
        },
        "name" : "Group_3"
      },
      {
        "maskFrame" : null,
        "visible" : true,
        "id" : "58800D63-9191-4510-AC8C-1DEF92D377DF",
        "children" : [

        ],
        "image" : {
          "path" : "images\/Group-58800D63-9191-4510-AC8C-1DEF92D377DF.png",
          "frame" : {
            "y" : 21,
            "x" : 107,
            "width" : 553,
            "height" : 560
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 21,
          "x" : 107,
          "width" : 553,
          "height" : 560
        },
        "name" : "Group"
      }
    ],
    "image" : {
      "path" : "images\/Custom_Preset-BDA10850-0078-486C-A884-C87DBDE2C1C2.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 800,
        "height" : 600
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 800,
      "height" : 600
    },
    "name" : "Custom_Preset"
  },
  {
    "maskFrame" : null,
    "visible" : false,
    "id" : "E7DD0823-3262-4A41-A451-CCEB466674CB",
    "children" : [
      {
        "maskFrame" : null,
        "visible" : true,
        "id" : "14C96B24-CE5E-4F98-AED4-251F318C3A94",
        "children" : [
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "FB075409-C7B9-41FC-AF08-673DBA5FD9D7",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "F22218B1-DCD1-4C52-8619-D78CCD6CD2EF",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/play-F22218B1-DCD1-4C52-8619-D78CCD6CD2EF.png",
                  "frame" : {
                    "y" : 953,
                    "x" : 289,
                    "width" : 65,
                    "height" : 65
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 953,
                  "x" : 289,
                  "width" : 65,
                  "height" : 65
                },
                "name" : "play"
              }
            ],
            "image" : {
              "path" : "images\/play-FB075409-C7B9-41FC-AF08-673DBA5FD9D7.png",
              "frame" : {
                "y" : 953,
                "x" : 289,
                "width" : 65,
                "height" : 65
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 953,
              "x" : 289,
              "width" : 65,
              "height" : 65
            },
            "name" : "play"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "D8B07BE1-D886-439F-950F-2881D78EACDF",
            "children" : [

            ],
            "image" : {
              "path" : "images\/pause-D8B07BE1-D886-439F-950F-2881D78EACDF.png",
              "frame" : {
                "y" : 948,
                "x" : 290,
                "width" : 53,
                "height" : 78
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 948,
              "x" : 290,
              "width" : 53,
              "height" : 78
            },
            "name" : "pause"
          }
        ],
        "image" : {
          "path" : "images\/control-14C96B24-CE5E-4F98-AED4-251F318C3A94.png",
          "frame" : {
            "y" : 899,
            "x" : 229,
            "width" : 176,
            "height" : 176
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 899,
          "x" : 229,
          "width" : 176,
          "height" : 176
        },
        "name" : "control"
      },
      {
        "maskFrame" : null,
        "visible" : true,
        "id" : "DF8631A3-1097-4DBB-8E32-0554DE156769",
        "children" : [

        ],
        "image" : {
          "path" : "images\/player-DF8631A3-1097-4DBB-8E32-0554DE156769.png",
          "frame" : {
            "y" : 80,
            "x" : 0,
            "width" : 640,
            "height" : 640
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 80,
          "x" : 0,
          "width" : 640,
          "height" : 640
        },
        "name" : "player"
      }
    ],
    "image" : {
      "path" : "images\/Portrait-E7DD0823-3262-4A41-A451-CCEB466674CB.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 640,
        "height" : 1136
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 640,
      "height" : 1136
    },
    "name" : "Portrait"
  }
]