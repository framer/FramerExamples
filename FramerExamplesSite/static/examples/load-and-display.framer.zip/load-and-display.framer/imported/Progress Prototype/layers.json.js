window.__imported__ = window.__imported__ || {};
window.__imported__["Progress Prototype/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "56A068CA-0FB0-46BA-A2A5-02C338B166C7",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "D64D8336-2A7C-4507-986F-96F1A579FBC2",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "4DAA3482-3185-45CE-972E-8285D65202D9",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/bottomBar-4DAA3482-3185-45CE-972E-8285D65202D9.png",
              "frame" : {
                "y" : 1052,
                "x" : 0,
                "width" : 640,
                "height" : 84
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 1052,
              "x" : 0,
              "width" : 640,
              "height" : 84
            },
            "name" : "bottomBar"
          },
          {
            "maskFrame" : null,
            "id" : "D0934A86-6FF5-48CD-AF42-66DFC907B95B",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "08D611BC-8E89-4970-BF8A-3A841AAEAB23",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconInfo-08D611BC-8E89-4970-BF8A-3A841AAEAB23.png",
                  "frame" : {
                    "y" : 1016,
                    "x" : 576,
                    "width" : 28,
                    "height" : 28
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 1016,
                  "x" : 576,
                  "width" : 28,
                  "height" : 28
                },
                "name" : "iconInfo"
              },
              {
                "maskFrame" : null,
                "id" : "73E52D5A-DF66-40EC-AF93-DC696E2D5BA6",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconNote-73E52D5A-DF66-40EC-AF93-DC696E2D5BA6.png",
                  "frame" : {
                    "y" : 994,
                    "x" : 28,
                    "width" : 72,
                    "height" : 72
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 994,
                  "x" : 28,
                  "width" : 72,
                  "height" : 72
                },
                "name" : "iconNote"
              }
            ],
            "image" : {
              "path" : "images\/item8-D0934A86-6FF5-48CD-AF42-66DFC907B95B.png",
              "frame" : {
                "y" : 994,
                "x" : 28,
                "width" : 576,
                "height" : 72
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 994,
              "x" : 28,
              "width" : 576,
              "height" : 72
            },
            "name" : "item8"
          },
          {
            "maskFrame" : null,
            "id" : "92D64C86-CD02-4B33-9FA9-1D0CC1471855",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "F378CFAE-4AF3-4092-923D-BDABD886C3B8",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconInfo-F378CFAE-4AF3-4092-923D-BDABD886C3B8.png",
                  "frame" : {
                    "y" : 888,
                    "x" : 576,
                    "width" : 28,
                    "height" : 28
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 888,
                  "x" : 576,
                  "width" : 28,
                  "height" : 28
                },
                "name" : "iconInfo"
              },
              {
                "maskFrame" : null,
                "id" : "6AA40562-327F-4F3A-8E06-02F5098A74EF",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconNote-6AA40562-327F-4F3A-8E06-02F5098A74EF.png",
                  "frame" : {
                    "y" : 867,
                    "x" : 28,
                    "width" : 72,
                    "height" : 72
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 867,
                  "x" : 28,
                  "width" : 72,
                  "height" : 72
                },
                "name" : "iconNote"
              }
            ],
            "image" : {
              "path" : "images\/item7-92D64C86-CD02-4B33-9FA9-1D0CC1471855.png",
              "frame" : {
                "y" : 867,
                "x" : 28,
                "width" : 576,
                "height" : 72
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 867,
              "x" : 28,
              "width" : 576,
              "height" : 72
            },
            "name" : "item7"
          },
          {
            "maskFrame" : null,
            "id" : "E82167B5-AA83-4AE4-9284-32624C339A68",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/item6-E82167B5-AA83-4AE4-9284-32624C339A68.png",
              "frame" : {
                "y" : 785,
                "x" : 129,
                "width" : 50,
                "height" : 19
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 785,
              "x" : 129,
              "width" : 50,
              "height" : 19
            },
            "name" : "item6"
          },
          {
            "maskFrame" : null,
            "id" : "DC65D60E-3394-492E-A5FB-7E30B2C5F968",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/item5-DC65D60E-3394-492E-A5FB-7E30B2C5F968.png",
              "frame" : {
                "y" : 751,
                "x" : 124,
                "width" : 504,
                "height" : 2
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 751,
              "x" : 124,
              "width" : 504,
              "height" : 2
            },
            "name" : "item5"
          },
          {
            "maskFrame" : null,
            "id" : "1017C16D-5A20-4ECC-B839-E69A2DC588A9",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "4A10C81F-65DD-46F6-9CB4-F2E099C37E1D",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconInfo-4A10C81F-65DD-46F6-9CB4-F2E099C37E1D.png",
                  "frame" : {
                    "y" : 661,
                    "x" : 576,
                    "width" : 28,
                    "height" : 28
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 661,
                  "x" : 576,
                  "width" : 28,
                  "height" : 28
                },
                "name" : "iconInfo"
              },
              {
                "maskFrame" : null,
                "id" : "8EE3A70F-B1AD-4E46-8829-47C1D2D60FCF",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconFolder-8EE3A70F-B1AD-4E46-8829-47C1D2D60FCF.png",
                  "frame" : {
                    "y" : 639,
                    "x" : 28,
                    "width" : 72,
                    "height" : 72
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 639,
                  "x" : 28,
                  "width" : 72,
                  "height" : 72
                },
                "name" : "iconFolder"
              }
            ],
            "image" : {
              "path" : "images\/item4-1017C16D-5A20-4ECC-B839-E69A2DC588A9.png",
              "frame" : {
                "y" : 639,
                "x" : 28,
                "width" : 576,
                "height" : 72
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 639,
              "x" : 28,
              "width" : 576,
              "height" : 72
            },
            "name" : "item4"
          },
          {
            "maskFrame" : null,
            "id" : "B5445EFF-9FF4-46EB-8591-5CFD09759AAF",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "29BA4775-B9A1-4EEC-B3DC-90EB10BB1E14",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconInfo-29BA4775-B9A1-4EEC-B3DC-90EB10BB1E14.png",
                  "frame" : {
                    "y" : 532,
                    "x" : 576,
                    "width" : 28,
                    "height" : 28
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 532,
                  "x" : 576,
                  "width" : 28,
                  "height" : 28
                },
                "name" : "iconInfo"
              },
              {
                "maskFrame" : null,
                "id" : "E94B2612-1363-4790-86BE-6A8F5BE79211",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconFolder-E94B2612-1363-4790-86BE-6A8F5BE79211.png",
                  "frame" : {
                    "y" : 512,
                    "x" : 28,
                    "width" : 72,
                    "height" : 72
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 512,
                  "x" : 28,
                  "width" : 72,
                  "height" : 72
                },
                "name" : "iconFolder"
              }
            ],
            "image" : {
              "path" : "images\/item3-B5445EFF-9FF4-46EB-8591-5CFD09759AAF.png",
              "frame" : {
                "y" : 512,
                "x" : 28,
                "width" : 576,
                "height" : 72
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 512,
              "x" : 28,
              "width" : 576,
              "height" : 72
            },
            "name" : "item3"
          },
          {
            "maskFrame" : null,
            "id" : "601E4288-2DFF-4017-A4F7-518F86682DE7",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "0B42BD5E-7179-4338-B66E-D19AE0D969FB",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconInfo-0B42BD5E-7179-4338-B66E-D19AE0D969FB.png",
                  "frame" : {
                    "y" : 405,
                    "x" : 576,
                    "width" : 28,
                    "height" : 28
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 405,
                  "x" : 576,
                  "width" : 28,
                  "height" : 28
                },
                "name" : "iconInfo"
              },
              {
                "maskFrame" : null,
                "id" : "AD075CFF-F71E-49E1-B0BD-F96D1426ABC3",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconFolder-AD075CFF-F71E-49E1-B0BD-F96D1426ABC3.png",
                  "frame" : {
                    "y" : 383,
                    "x" : 28,
                    "width" : 72,
                    "height" : 72
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 383,
                  "x" : 28,
                  "width" : 72,
                  "height" : 72
                },
                "name" : "iconFolder"
              }
            ],
            "image" : {
              "path" : "images\/item2-601E4288-2DFF-4017-A4F7-518F86682DE7.png",
              "frame" : {
                "y" : 383,
                "x" : 28,
                "width" : 576,
                "height" : 72
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 383,
              "x" : 28,
              "width" : 576,
              "height" : 72
            },
            "name" : "item2"
          },
          {
            "maskFrame" : null,
            "id" : "0D1C8546-8612-495A-82C6-E50D494A86E5",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/item1-0D1C8546-8612-495A-82C6-E50D494A86E5.png",
              "frame" : {
                "y" : 301,
                "x" : 129,
                "width" : 80,
                "height" : 19
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 301,
              "x" : 129,
              "width" : 80,
              "height" : 19
            },
            "name" : "item1"
          },
          {
            "maskFrame" : null,
            "id" : "C3B1D84C-2E58-4D3A-94E0-F2F93DF3B4D8",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/iconNew-C3B1D84C-2E58-4D3A-94E0-F2F93DF3B4D8.png",
              "frame" : {
                "y" : 232,
                "x" : 23,
                "width" : 82,
                "height" : 82
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 232,
              "x" : 23,
              "width" : 82,
              "height" : 82
            },
            "name" : "iconNew"
          },
          {
            "maskFrame" : null,
            "id" : "AAE4F952-AA65-41A9-9E64-B80B29A8AA3C",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : {
                  "y" : 8,
                  "x" : 538,
                  "width" : 14,
                  "height" : 24
                },
                "id" : "2FEBDC0A-B3DA-46FC-B67A-4ACED8C7758C",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconBattery-2FEBDC0A-B3DA-46FC-B67A-4ACED8C7758C.png",
                  "frame" : {
                    "y" : 8,
                    "x" : 538,
                    "width" : 14,
                    "height" : 24
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 8,
                  "x" : 538,
                  "width" : 14,
                  "height" : 24
                },
                "name" : "iconBattery"
              },
              {
                "maskFrame" : {
                  "y" : 10,
                  "x" : 491,
                  "width" : 23,
                  "height" : 23
                },
                "id" : "E23C53C2-049D-4473-868E-0EE5386C3B29",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconSignal-E23C53C2-049D-4473-868E-0EE5386C3B29.png",
                  "frame" : {
                    "y" : 10,
                    "x" : 491,
                    "width" : 23,
                    "height" : 23
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 10,
                  "x" : 491,
                  "width" : 23,
                  "height" : 23
                },
                "name" : "iconSignal"
              },
              {
                "maskFrame" : {
                  "y" : 10,
                  "x" : 446,
                  "width" : 26,
                  "height" : 23
                },
                "id" : "F92DBE35-B3E1-42E5-A045-FFE7F8C0DB5D",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconWifi-F92DBE35-B3E1-42E5-A045-FFE7F8C0DB5D.png",
                  "frame" : {
                    "y" : 10,
                    "x" : 446,
                    "width" : 26,
                    "height" : 23
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 10,
                  "x" : 446,
                  "width" : 26,
                  "height" : 23
                },
                "name" : "iconWifi"
              },
              {
                "maskFrame" : null,
                "id" : "452E250A-A285-43E0-9E39-BD1B812F857A",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconSearch-452E250A-A285-43E0-9E39-BD1B812F857A.png",
                  "frame" : {
                    "y" : 76,
                    "x" : 489,
                    "width" : 31,
                    "height" : 31
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 76,
                  "x" : 489,
                  "width" : 31,
                  "height" : 31
                },
                "name" : "iconSearch"
              }
            ],
            "image" : {
              "path" : "images\/Top-AAE4F952-AA65-41A9-9E64-B80B29A8AA3C.png",
              "frame" : {
                "y" : 0,
                "x" : 0,
                "width" : 640,
                "height" : 278
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 0,
              "x" : 0,
              "width" : 640,
              "height" : 278
            },
            "name" : "Top"
          },
          {
            "maskFrame" : null,
            "id" : "84C32AE2-D359-47D2-97B5-FDBA86FC7FF4",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Background-84C32AE2-D359-47D2-97B5-FDBA86FC7FF4.png",
              "frame" : {
                "y" : 0,
                "x" : 0,
                "width" : 640,
                "height" : 1136
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 0,
              "x" : 0,
              "width" : 640,
              "height" : 1136
            },
            "name" : "Background"
          }
        ],
        "image" : {
          "path" : "images\/Screen-D64D8336-2A7C-4507-986F-96F1A579FBC2.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 640,
            "height" : 1136
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 640,
          "height" : 1136
        },
        "name" : "Screen"
      }
    ],
    "image" : {
      "path" : "images\/Portrait-56A068CA-0FB0-46BA-A2A5-02C338B166C7.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 640,
        "height" : 1136
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 640,
      "height" : 1136
    },
    "name" : "Portrait"
  }
]