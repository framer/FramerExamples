window.__imported__ = window.__imported__ || {};
window.__imported__["Progress Prototype/layers.json.js"] = [
  {
    "maskFrame" : null,
    "visible" : true,
    "id" : "56A068CA-0FB0-46BA-A2A5-02C338B166C7",
    "children" : [
      {
        "maskFrame" : null,
        "visible" : true,
        "id" : "D64D8336-2A7C-4507-986F-96F1A579FBC2",
        "children" : [
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "59C6726B-F2CB-44CA-AC89-2CA6D3155CB0",
            "children" : [

            ],
            "image" : {
              "path" : "images\/bottomBar-59C6726B-F2CB-44CA-AC89-2CA6D3155CB0.png",
              "frame" : {
                "y" : 1044,
                "x" : -4,
                "width" : 648,
                "height" : 96
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 1044,
              "x" : -4,
              "width" : 648,
              "height" : 96
            },
            "name" : "bottomBar"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "D0934A86-6FF5-48CD-AF42-66DFC907B95B",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "08D611BC-8E89-4970-BF8A-3A841AAEAB23",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconInfo-08D611BC-8E89-4970-BF8A-3A841AAEAB23.png",
                  "frame" : {
                    "y" : 1016,
                    "x" : 575,
                    "width" : 28,
                    "height" : 28
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 1016,
                  "x" : 575,
                  "width" : 28,
                  "height" : 28
                },
                "name" : "iconInfo"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "73E52D5A-DF66-40EC-AF93-DC696E2D5BA6",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconNote-73E52D5A-DF66-40EC-AF93-DC696E2D5BA6.png",
                  "frame" : {
                    "y" : 993,
                    "x" : 23,
                    "width" : 72,
                    "height" : 72
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 993,
                  "x" : 23,
                  "width" : 72,
                  "height" : 72
                },
                "name" : "iconNote"
              }
            ],
            "image" : {
              "path" : "images\/item8-D0934A86-6FF5-48CD-AF42-66DFC907B95B.png",
              "frame" : {
                "y" : 993,
                "x" : 23,
                "width" : 580,
                "height" : 72
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 993,
              "x" : 23,
              "width" : 580,
              "height" : 72
            },
            "name" : "item8"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "92D64C86-CD02-4B33-9FA9-1D0CC1471855",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "F378CFAE-4AF3-4092-923D-BDABD886C3B8",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconInfo-F378CFAE-4AF3-4092-923D-BDABD886C3B8.png",
                  "frame" : {
                    "y" : 886,
                    "x" : 575,
                    "width" : 28,
                    "height" : 28
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 886,
                  "x" : 575,
                  "width" : 28,
                  "height" : 28
                },
                "name" : "iconInfo"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "6AA40562-327F-4F3A-8E06-02F5098A74EF",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconNote-6AA40562-327F-4F3A-8E06-02F5098A74EF.png",
                  "frame" : {
                    "y" : 863,
                    "x" : 23,
                    "width" : 72,
                    "height" : 72
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 863,
                  "x" : 23,
                  "width" : 72,
                  "height" : 72
                },
                "name" : "iconNote"
              }
            ],
            "image" : {
              "path" : "images\/item7-92D64C86-CD02-4B33-9FA9-1D0CC1471855.png",
              "frame" : {
                "y" : 863,
                "x" : 23,
                "width" : 580,
                "height" : 72
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 863,
              "x" : 23,
              "width" : 580,
              "height" : 72
            },
            "name" : "item7"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "E82167B5-AA83-4AE4-9284-32624C339A68",
            "children" : [

            ],
            "image" : {
              "path" : "images\/item6-E82167B5-AA83-4AE4-9284-32624C339A68.png",
              "frame" : {
                "y" : 784,
                "x" : 123,
                "width" : 47,
                "height" : 29
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 784,
              "x" : 123,
              "width" : 47,
              "height" : 29
            },
            "name" : "item6"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "DC65D60E-3394-492E-A5FB-7E30B2C5F968",
            "children" : [

            ],
            "image" : {
              "path" : "images\/item5-DC65D60E-3394-492E-A5FB-7E30B2C5F968.png",
              "frame" : {
                "y" : 749,
                "x" : 124,
                "width" : 504,
                "height" : 2
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 749,
              "x" : 124,
              "width" : 504,
              "height" : 2
            },
            "name" : "item5"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "1017C16D-5A20-4ECC-B839-E69A2DC588A9",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "4A10C81F-65DD-46F6-9CB4-F2E099C37E1D",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconInfo-4A10C81F-65DD-46F6-9CB4-F2E099C37E1D.png",
                  "frame" : {
                    "y" : 659,
                    "x" : 575,
                    "width" : 28,
                    "height" : 28
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 659,
                  "x" : 575,
                  "width" : 28,
                  "height" : 28
                },
                "name" : "iconInfo"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "8EE3A70F-B1AD-4E46-8829-47C1D2D60FCF",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconFolder-8EE3A70F-B1AD-4E46-8829-47C1D2D60FCF.png",
                  "frame" : {
                    "y" : 636,
                    "x" : 23,
                    "width" : 72,
                    "height" : 72
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 636,
                  "x" : 23,
                  "width" : 72,
                  "height" : 72
                },
                "name" : "iconFolder"
              }
            ],
            "image" : {
              "path" : "images\/item4-1017C16D-5A20-4ECC-B839-E69A2DC588A9.png",
              "frame" : {
                "y" : 636,
                "x" : 23,
                "width" : 580,
                "height" : 72
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 636,
              "x" : 23,
              "width" : 580,
              "height" : 72
            },
            "name" : "item4"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "B5445EFF-9FF4-46EB-8591-5CFD09759AAF",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "29BA4775-B9A1-4EEC-B3DC-90EB10BB1E14",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconInfo-29BA4775-B9A1-4EEC-B3DC-90EB10BB1E14.png",
                  "frame" : {
                    "y" : 532,
                    "x" : 576,
                    "width" : 28,
                    "height" : 28
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 532,
                  "x" : 576,
                  "width" : 28,
                  "height" : 28
                },
                "name" : "iconInfo"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "E94B2612-1363-4790-86BE-6A8F5BE79211",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconFolder-E94B2612-1363-4790-86BE-6A8F5BE79211.png",
                  "frame" : {
                    "y" : 509,
                    "x" : 24,
                    "width" : 72,
                    "height" : 72
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 509,
                  "x" : 24,
                  "width" : 72,
                  "height" : 72
                },
                "name" : "iconFolder"
              }
            ],
            "image" : {
              "path" : "images\/item3-B5445EFF-9FF4-46EB-8591-5CFD09759AAF.png",
              "frame" : {
                "y" : 509,
                "x" : 24,
                "width" : 580,
                "height" : 72
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 509,
              "x" : 24,
              "width" : 580,
              "height" : 72
            },
            "name" : "item3"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "601E4288-2DFF-4017-A4F7-518F86682DE7",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "0B42BD5E-7179-4338-B66E-D19AE0D969FB",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconInfo-0B42BD5E-7179-4338-B66E-D19AE0D969FB.png",
                  "frame" : {
                    "y" : 404,
                    "x" : 575,
                    "width" : 28,
                    "height" : 28
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 404,
                  "x" : 575,
                  "width" : 28,
                  "height" : 28
                },
                "name" : "iconInfo"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "AD075CFF-F71E-49E1-B0BD-F96D1426ABC3",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconFolder-AD075CFF-F71E-49E1-B0BD-F96D1426ABC3.png",
                  "frame" : {
                    "y" : 381,
                    "x" : 23,
                    "width" : 72,
                    "height" : 72
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 381,
                  "x" : 23,
                  "width" : 72,
                  "height" : 72
                },
                "name" : "iconFolder"
              }
            ],
            "image" : {
              "path" : "images\/item2-601E4288-2DFF-4017-A4F7-518F86682DE7.png",
              "frame" : {
                "y" : 381,
                "x" : 23,
                "width" : 580,
                "height" : 72
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 381,
              "x" : 23,
              "width" : 580,
              "height" : 72
            },
            "name" : "item2"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "0D1C8546-8612-495A-82C6-E50D494A86E5",
            "children" : [

            ],
            "image" : {
              "path" : "images\/item1-0D1C8546-8612-495A-82C6-E50D494A86E5.png",
              "frame" : {
                "y" : 298,
                "x" : 123,
                "width" : 77,
                "height" : 29
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 298,
              "x" : 123,
              "width" : 77,
              "height" : 29
            },
            "name" : "item1"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "C3B1D84C-2E58-4D3A-94E0-F2F93DF3B4D8",
            "children" : [

            ],
            "image" : {
              "path" : "images\/iconNew-C3B1D84C-2E58-4D3A-94E0-F2F93DF3B4D8.png",
              "frame" : {
                "y" : 220,
                "x" : 23,
                "width" : 82,
                "height" : 82
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 220,
              "x" : 23,
              "width" : 82,
              "height" : 82
            },
            "name" : "iconNew"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "AAE4F952-AA65-41A9-9E64-B80B29A8AA3C",
            "children" : [
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "2FEBDC0A-B3DA-46FC-B67A-4ACED8C7758C",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconBattery-2FEBDC0A-B3DA-46FC-B67A-4ACED8C7758C.png",
                  "frame" : {
                    "y" : 7,
                    "x" : 538,
                    "width" : 14,
                    "height" : 24
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 7,
                  "x" : 538,
                  "width" : 14,
                  "height" : 24
                },
                "name" : "iconBattery"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "E23C53C2-049D-4473-868E-0EE5386C3B29",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconSignal-E23C53C2-049D-4473-868E-0EE5386C3B29.png",
                  "frame" : {
                    "y" : 8,
                    "x" : 491,
                    "width" : 22,
                    "height" : 22
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 8,
                  "x" : 491,
                  "width" : 22,
                  "height" : 22
                },
                "name" : "iconSignal"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "F92DBE35-B3E1-42E5-A045-FFE7F8C0DB5D",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconWifi-F92DBE35-B3E1-42E5-A045-FFE7F8C0DB5D.png",
                  "frame" : {
                    "y" : 8,
                    "x" : 447,
                    "width" : 25,
                    "height" : 23
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 8,
                  "x" : 447,
                  "width" : 25,
                  "height" : 23
                },
                "name" : "iconWifi"
              },
              {
                "maskFrame" : null,
                "visible" : true,
                "id" : "452E250A-A285-43E0-9E39-BD1B812F857A",
                "children" : [

                ],
                "image" : {
                  "path" : "images\/iconSearch-452E250A-A285-43E0-9E39-BD1B812F857A.png",
                  "frame" : {
                    "y" : 66,
                    "x" : 489,
                    "width" : 31,
                    "height" : 31
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 66,
                  "x" : 489,
                  "width" : 31,
                  "height" : 31
                },
                "name" : "iconSearch"
              }
            ],
            "image" : {
              "path" : "images\/Top-AAE4F952-AA65-41A9-9E64-B80B29A8AA3C.png",
              "frame" : {
                "y" : -4,
                "x" : -6,
                "width" : 653,
                "height" : 272
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : -4,
              "x" : -6,
              "width" : 653,
              "height" : 272
            },
            "name" : "Top"
          },
          {
            "maskFrame" : null,
            "visible" : true,
            "id" : "84C32AE2-D359-47D2-97B5-FDBA86FC7FF4",
            "children" : [

            ],
            "image" : {
              "path" : "images\/Background-84C32AE2-D359-47D2-97B5-FDBA86FC7FF4.png",
              "frame" : {
                "y" : 0,
                "x" : 0,
                "width" : 640,
                "height" : 1136
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 0,
              "x" : 0,
              "width" : 640,
              "height" : 1136
            },
            "name" : "Background"
          }
        ],
        "image" : {
          "path" : "images\/Screen-D64D8336-2A7C-4507-986F-96F1A579FBC2.png",
          "frame" : {
            "y" : -4,
            "x" : -6,
            "width" : 653,
            "height" : 1148
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : -4,
          "x" : -6,
          "width" : 653,
          "height" : 1148
        },
        "name" : "Screen"
      }
    ],
    "image" : {
      "path" : "images\/Portrait-56A068CA-0FB0-46BA-A2A5-02C338B166C7.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 640,
        "height" : 1136
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 640,
      "height" : 1136
    },
    "name" : "Portrait"
  }
]