window.__imported__ = window.__imported__ || {};
window.__imported__["glances/layers.json.js"] = [
  {
    "maskFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 272,
      "height" : 340
    },
    "id" : "3E08C080-821A-4FF0-BEFB-429A61F7C6A0",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "E574E87D-06CF-41B5-AEEA-71FF8A770153",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-day-E574E87D-06CF-41B5-AEEA-71FF8A770153.png",
          "frame" : {
            "y" : 115,
            "x" : 233,
            "width" : 34,
            "height" : 50
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 115,
          "x" : 233,
          "width" : 34,
          "height" : 50
        },
        "name" : "day"
      }
    ],
    "image" : {
      "path" : "images\/Layer-home-3E08C080-821A-4FF0-BEFB-429A61F7C6A0.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 272,
        "height" : 340
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 272,
      "height" : 340
    },
    "name" : "home"
  },
  {
    "maskFrame" : null,
    "id" : "4584C7B3-1C6C-4BE4-ABC7-72A15F3B2E69",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-battery-4584C7B3-1C6C-4BE4-ABC7-72A15F3B2E69.png",
      "frame" : {
        "y" : 356,
        "x" : 0,
        "width" : 272,
        "height" : 340
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 356,
      "x" : 0,
      "width" : 272,
      "height" : 340
    },
    "name" : "battery"
  },
  {
    "maskFrame" : null,
    "id" : "90BB7056-5E57-4E97-8B6F-85579E7670BF",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-weather-90BB7056-5E57-4E97-8B6F-85579E7670BF.png",
      "frame" : {
        "y" : 356,
        "x" : 288,
        "width" : 272,
        "height" : 340
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 356,
      "x" : 288,
      "width" : 272,
      "height" : 340
    },
    "name" : "weather"
  },
  {
    "maskFrame" : null,
    "id" : "CE09B4EE-0FF2-48C6-BBA3-A9D12FD8A2DA",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/Layer-calendar-CE09B4EE-0FF2-48C6-BBA3-A9D12FD8A2DA.png",
      "frame" : {
        "y" : 356,
        "x" : 576,
        "width" : 272,
        "height" : 340
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 356,
      "x" : 576,
      "width" : 272,
      "height" : 340
    },
    "name" : "calendar"
  }
]