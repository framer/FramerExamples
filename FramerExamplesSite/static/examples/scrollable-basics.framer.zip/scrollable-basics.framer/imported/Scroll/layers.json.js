window.__imported__ = window.__imported__ || {};
window.__imported__["Scroll/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "EE70AF9C-3CF1-46A9-9303-9AB4D84E362E",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/content-EE70AF9C-3CF1-46A9-9303-9AB4D84E362E.png",
      "frame" : {
        "y" : 21,
        "x" : 20,
        "width" : 160,
        "height" : 264
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 21,
      "x" : 20,
      "width" : 160,
      "height" : 264
    },
    "name" : "content"
  }
]