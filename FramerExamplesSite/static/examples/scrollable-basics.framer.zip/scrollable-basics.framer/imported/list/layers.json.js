window.__imported__ = window.__imported__ || {};
window.__imported__["list/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "A04771AB-07A8-42BB-A6FD-686FD57B9B91",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/content-A04771AB-07A8-42BB-A6FD-686FD57B9B91.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 120,
        "height" : 200
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 120,
      "height" : 200
    },
    "name" : "content"
  }
]