window.__imported__ = window.__imported__ || {};
window.__imported__["Framer - WebMagazin/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "F4E0B56A-531A-44CE-B625-735E9FFDC177",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : {
          "y" : -100,
          "x" : -100,
          "width" : 472,
          "height" : 540
        },
        "id" : "3C5CF8A8-7A05-48A8-8988-CFA7C54635A9",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "C761D4FA-7C83-452C-96F4-65BFAA8F831E",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "A9C6FDD8-C873-40F2-AD12-7D3C460D2FC2",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "3381D952-F889-4343-BF24-8120B30AECEC",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/2-3381D952-F889-4343-BF24-8120B30AECEC.png",
                      "frame" : {
                        "y" : 31,
                        "x" : 54,
                        "width" : 32,
                        "height" : 24
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 31,
                      "x" : 54,
                      "width" : 32,
                      "height" : 24
                    },
                    "name" : "layer2"
                  },
                  {
                    "maskFrame" : null,
                    "id" : "36D8DC40-0239-449A-BB8F-A27A334E423E",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/1-36D8DC40-0239-449A-BB8F-A27A334E423E.png",
                      "frame" : {
                        "y" : 31,
                        "x" : 26,
                        "width" : 32,
                        "height" : 24
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 31,
                      "x" : 26,
                      "width" : 32,
                      "height" : 24
                    },
                    "name" : "layer1"
                  }
                ],
                "image" : {
                  "path" : "images\/1__2-A9C6FDD8-C873-40F2-AD12-7D3C460D2FC2.png",
                  "frame" : {
                    "y" : 31,
                    "x" : 26,
                    "width" : 60,
                    "height" : 24
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 31,
                  "x" : 26,
                  "width" : 60,
                  "height" : 24
                },
                "name" : "layer1__2"
              }
            ],
            "image" : {
              "path" : "images\/LogoSmall-C761D4FA-7C83-452C-96F4-65BFAA8F831E.png",
              "frame" : {
                "y" : 3,
                "x" : 16,
                "width" : 80,
                "height" : 80
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 3,
              "x" : 16,
              "width" : 80,
              "height" : 80
            },
            "name" : "LogoSmall"
          },
          {
            "maskFrame" : null,
            "id" : "74D44456-7DE2-4DB2-BCFE-A69356160221",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Time-74D44456-7DE2-4DB2-BCFE-A69356160221.png",
              "frame" : {
                "y" : 6,
                "x" : 191,
                "width" : 73,
                "height" : 22
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 6,
              "x" : 191,
              "width" : 73,
              "height" : 22
            },
            "name" : "Time"
          },
          {
            "maskFrame" : null,
            "id" : "26892E14-BB7C-4399-B75E-27447EC8B255",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Header-26892E14-BB7C-4399-B75E-27447EC8B255.png",
              "frame" : {
                "y" : 36,
                "x" : 2,
                "width" : 268,
                "height" : 54
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 36,
              "x" : 2,
              "width" : 268,
              "height" : 54
            },
            "name" : "Header"
          },
          {
            "maskFrame" : null,
            "id" : "79454DC9-7A40-4BE6-83B9-DAD7B1ECDF8D",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Body-79454DC9-7A40-4BE6-83B9-DAD7B1ECDF8D.png",
              "frame" : {
                "y" : 36,
                "x" : 2,
                "width" : 268,
                "height" : 201
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 36,
              "x" : 2,
              "width" : 268,
              "height" : 201
            },
            "name" : "Body"
          },
          {
            "maskFrame" : null,
            "id" : "ECBE8B5B-2C7A-4536-ADA5-FCB5EC52D80B",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Action_Button_1-ECBE8B5B-2C7A-4536-ADA5-FCB5EC52D80B.png",
              "frame" : {
                "y" : 245,
                "x" : 2,
                "width" : 268,
                "height" : 75
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 245,
              "x" : 2,
              "width" : 268,
              "height" : 75
            },
            "name" : "Action_Button_1"
          },
          {
            "maskFrame" : null,
            "id" : "419AFF21-98B5-4E0C-B4E4-DC319A7B5C53",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Action_Button_2-419AFF21-98B5-4E0C-B4E4-DC319A7B5C53.png",
              "frame" : {
                "y" : 328,
                "x" : 2,
                "width" : 268,
                "height" : 75
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 328,
              "x" : 2,
              "width" : 268,
              "height" : 75
            },
            "name" : "Action_Button_2"
          },
          {
            "maskFrame" : null,
            "id" : "20A885B3-2E90-4BF7-A1D9-D6C927B057C7",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Action_Button_3-20A885B3-2E90-4BF7-A1D9-D6C927B057C7.png",
              "frame" : {
                "y" : 411,
                "x" : 2,
                "width" : 268,
                "height" : 75
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 411,
              "x" : 2,
              "width" : 268,
              "height" : 75
            },
            "name" : "Action_Button_3"
          },
          {
            "maskFrame" : null,
            "id" : "E5ED2A59-28AB-4772-83A0-BC3C2F8272B9",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Dismiss-E5ED2A59-28AB-4772-83A0-BC3C2F8272B9.png",
              "frame" : {
                "y" : 510,
                "x" : 2,
                "width" : 268,
                "height" : 75
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 510,
              "x" : 2,
              "width" : 268,
              "height" : 75
            },
            "name" : "Dismiss"
          }
        ],
        "image" : {
          "path" : "images\/Content-3C5CF8A8-7A05-48A8-8988-CFA7C54635A9.png",
          "frame" : {
            "y" : 3,
            "x" : 2,
            "width" : 268,
            "height" : 337
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 3,
          "x" : 2,
          "width" : 268,
          "height" : 337
        },
        "name" : "Content"
      },
      {
        "maskFrame" : null,
        "id" : "6174E62D-7774-4FA3-A57F-CF66056993F3",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/BG-6174E62D-7774-4FA3-A57F-CF66056993F3.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 272,
            "height" : 600
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 272,
          "height" : 600
        },
        "name" : "BG"
      }
    ],
    "image" : {
      "path" : "images\/LongLook-F4E0B56A-531A-44CE-B625-735E9FFDC177.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 272,
        "height" : 600
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 272,
      "height" : 600
    },
    "name" : "LongLook"
  },
  {
    "maskFrame" : null,
    "id" : "E10595C8-7F86-42CF-936B-A66F2B220A36",
    "visible" : false,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "F9390E5B-D71D-48B3-96A9-7B15D767C4B1",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "64B24098-CB54-46A6-B199-1EC3E0F405A8",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "EACEFF4C-ADC1-469D-B0EF-2339F8F576AC",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "5B21C75F-FC04-4D67-9011-5C295B5EDD88",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/2-5B21C75F-FC04-4D67-9011-5C295B5EDD88.png",
                      "frame" : {
                        "y" : 96,
                        "x" : 132,
                        "width" : 68,
                        "height" : 50
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 96,
                      "x" : 132,
                      "width" : 68,
                      "height" : 50
                    },
                    "name" : "layer2"
                  },
                  {
                    "maskFrame" : null,
                    "id" : "4DB168EB-B99F-4EF1-82E8-D7B9BC0B5B8C",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/1-4DB168EB-B99F-4EF1-82E8-D7B9BC0B5B8C.png",
                      "frame" : {
                        "y" : 96,
                        "x" : 72,
                        "width" : 68,
                        "height" : 50
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 96,
                      "x" : 72,
                      "width" : 68,
                      "height" : 50
                    },
                    "name" : "layer12"
                  }
                ],
                "image" : {
                  "path" : "images\/1__2-EACEFF4C-ADC1-469D-B0EF-2339F8F576AC.png",
                  "frame" : {
                    "y" : 96,
                    "x" : 72,
                    "width" : 128,
                    "height" : 50
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 96,
                  "x" : 72,
                  "width" : 128,
                  "height" : 50
                },
                "name" : "layer1__22"
              }
            ],
            "image" : {
              "path" : "images\/Logo-64B24098-CB54-46A6-B199-1EC3E0F405A8.png",
              "frame" : {
                "y" : 35,
                "x" : 50,
                "width" : 172,
                "height" : 172
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 35,
              "x" : 50,
              "width" : 172,
              "height" : 172
            },
            "name" : "Logo"
          },
          {
            "maskFrame" : null,
            "id" : "EC678B13-7A83-4655-8F3A-A3DFD54A548B",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Info-EC678B13-7A83-4655-8F3A-A3DFD54A548B.png",
              "frame" : {
                "y" : 227,
                "x" : 47,
                "width" : 179,
                "height" : 67
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 227,
              "x" : 47,
              "width" : 179,
              "height" : 67
            },
            "name" : "Info"
          },
          {
            "maskFrame" : {
              "y" : 0,
              "x" : 0,
              "width" : 272,
              "height" : 340
            },
            "id" : "CA32B0A7-E881-40B3-8981-500E9A3CA20F",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/FirstBG-CA32B0A7-E881-40B3-8981-500E9A3CA20F.png",
              "frame" : {
                "y" : 0,
                "x" : 0,
                "width" : 272,
                "height" : 340
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 0,
              "x" : 0,
              "width" : 272,
              "height" : 340
            },
            "name" : "FirstBG"
          }
        ],
        "image" : {
          "path" : "images\/Notification-F9390E5B-D71D-48B3-96A9-7B15D767C4B1.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 272,
            "height" : 340
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 272,
          "height" : 340
        },
        "name" : "Notification"
      }
    ],
    "image" : {
      "path" : "images\/ShortLook-E10595C8-7F86-42CF-936B-A66F2B220A36.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 272,
        "height" : 340
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 272,
      "height" : 340
    },
    "name" : "ShortLook"
  }
]
