window.__imported__ = window.__imported__ || {};
window.__imported__["Photoshop_Twitter_Original_150817/layers.json.js"] = [
	{
		"id": 407,
		"name": "bg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1242,
			"height": 2208
		},
		"maskFrame": null,
		"image": {
			"path": "images/bg.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 1242,
				"height": 2208
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "328038108"
	},
	{
		"id": 424,
		"name": "Circle0",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1242,
			"height": 2208
		},
		"maskFrame": null,
		"image": {
			"path": "images/Circle0.png",
			"frame": {
				"x": 301,
				"y": 1894,
				"width": 90,
				"height": 90
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1216314687"
	},
	{
		"id": 422,
		"name": "Circle1",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1242,
			"height": 2208
		},
		"maskFrame": null,
		"image": {
			"path": "images/Circle1.png",
			"frame": {
				"x": 409,
				"y": 1765,
				"width": 90,
				"height": 90
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "591009144"
	},
	{
		"id": 420,
		"name": "Circle2",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1242,
			"height": 2208
		},
		"maskFrame": null,
		"image": {
			"path": "images/Circle2.png",
			"frame": {
				"x": 570,
				"y": 1705,
				"width": 102,
				"height": 102
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "2038648306"
	},
	{
		"id": 416,
		"name": "Circle3",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1242,
			"height": 2208
		},
		"maskFrame": null,
		"image": {
			"path": "images/Circle3.png",
			"frame": {
				"x": 741,
				"y": 1765,
				"width": 90,
				"height": 90
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "2142815366"
	},
	{
		"id": 418,
		"name": "Circle4",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1242,
			"height": 2208
		},
		"maskFrame": null,
		"image": {
			"path": "images/Circle4.png",
			"frame": {
				"x": 851,
				"y": 1894,
				"width": 90,
				"height": 90
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1545251874"
	},
	{
		"id": 409,
		"name": "bgButton",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1242,
			"height": 2208
		},
		"maskFrame": null,
		"image": {
			"path": "images/bgButton.png",
			"frame": {
				"x": 517,
				"y": 1964,
				"width": 208,
				"height": 209
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1887502398"
	},
	{
		"id": 219,
		"name": "tweet",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1242,
			"height": 2208
		},
		"maskFrame": null,
		"image": {
			"path": "images/tweet.png",
			"frame": {
				"x": 579,
				"y": 2021,
				"width": 87,
				"height": 66
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "250554622"
	},
	{
		"id": 429,
		"name": "BirdX",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1242,
			"height": 2208
		},
		"maskFrame": null,
		"image": {
			"path": "images/BirdX.png",
			"frame": {
				"x": 597,
				"y": 2030,
				"width": 49,
				"height": 49
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "727534938"
	}
]