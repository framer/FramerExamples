window.__imported__ = window.__imported__ || {};
window.__imported__["facebookpaper/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "AC6C599E-235A-4069-BE4C-A7F1320813DF",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/bg-AC6C599E-235A-4069-BE4C-A7F1320813DF.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 640,
        "height" : 1136
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 640,
      "height" : 1136
    },
    "name" : "bg"
  },
  {
    "maskFrame" : null,
    "id" : "436E992C-FC46-4900-A959-27C9F352B1E7",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/photo-436E992C-FC46-4900-A959-27C9F352B1E7.png",
      "frame" : {
        "y" : 439,
        "x" : 39,
        "width" : 566,
        "height" : 566
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 439,
      "x" : 39,
      "width" : 566,
      "height" : 566
    },
    "name" : "photo"
  }
]